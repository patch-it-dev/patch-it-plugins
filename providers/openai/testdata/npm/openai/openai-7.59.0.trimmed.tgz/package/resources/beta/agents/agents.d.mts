import { APIResource } from "../../../core/resource.mjs";
import * as AgentsAPI from "./agents.mjs";
import * as TurnsAPI from "./sessions/turns/turns.mjs";
import * as AutomationsAPI from "./automations/automations.mjs";
import { Automation, AutomationAgentConfig, AutomationCreateParams, AutomationCreatedBy, AutomationDeleted, AutomationEnvironment, AutomationListParams, AutomationTarget, AutomationTargetParam, AutomationUpdateParams, Automations, AutomationsPage, CreateAutomationParamsOnce, CreateAutomationParamsPeriodic, OneTimeAutomation, PeriodicAutomation } from "./automations/automations.mjs";
import * as EnvironmentsAPI from "./environments/environments.mjs";
import { EnvironmentCreateParams, EnvironmentInfo, EnvironmentInfosPage, EnvironmentListParams, Environments } from "./environments/environments.mjs";
import * as SessionsAPI from "./sessions/sessions.mjs";
import { SessionCreateParams, SessionCreateParamsNonStreaming, SessionCreateParamsStreaming, SessionListParams, SessionUpdateParams, Sessions } from "./sessions/sessions.mjs";
import * as VaultsAPI from "./vaults/vaults.mjs";
import { Vault, VaultCreateParams, VaultDeleted, VaultListParams, VaultStatus, VaultStatusFilter, VaultUpdateParams, Vaults, VaultsPage } from "./vaults/vaults.mjs";
import { APIPromise } from "../../../core/api-promise.mjs";
import { CursorPage, type CursorPageParams, PagePromise } from "../../../core/pagination.mjs";
import { RequestOptions } from "../../../internal/request-options.mjs";
export declare class Agents extends APIResource {
    automations: AutomationsAPI.Automations;
    environments: EnvironmentsAPI.Environments;
    vaults: VaultsAPI.Vaults;
    sessions: SessionsAPI.Sessions;
    /**
     * Creates a reusable agent without storing credentials. See
     * [agent configuration](https://developers.openai.com/api/docs/guides/agents-api/configuration).
     *
     * @example
     * ```ts
     * const agent = await client.beta.agents.create({
     *   model: 'model',
     * });
     * ```
     */
    create(body: AgentCreateParams, options?: RequestOptions): APIPromise<Agent>;
    /**
     * Retrieves a reusable agent by ID. See
     * [agent configuration](https://developers.openai.com/api/docs/guides/agents-api/configuration).
     *
     * @example
     * ```ts
     * const agent = await client.beta.agents.retrieve('agent_id');
     * ```
     */
    retrieve(agentID: string, options?: RequestOptions): APIPromise<Agent>;
    /**
     * Updates a reusable agent. See
     * [agent configuration](https://developers.openai.com/api/docs/guides/agents-api/configuration).
     *
     * @example
     * ```ts
     * const agent = await client.beta.agents.update('agent_id');
     * ```
     */
    update(agentID: string, body?: AgentUpdateParams | null | undefined, options?: RequestOptions): APIPromise<Agent>;
    /**
     * Lists reusable agents in the current project. See
     * [agent configuration](https://developers.openai.com/api/docs/guides/agents-api/configuration).
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const agent of client.beta.agents.list()) {
     *   // ...
     * }
     * ```
     */
    list(query?: (AgentListParams & ({
        [K in 'method' | 'path' | 'query' | 'body' | 'headers' | 'maxRetries' | 'stream' | 'timeout' | 'httpAgent' | 'fetchOptions' | 'signal' | 'idempotencyKey' | 'defaultBaseURL' | '__metadata' | '__binaryRequest' | '__binaryResponse' | '__streamClass' | '__streamMode' | '__security' | '__synthesizeEventData']?: never;
    } | null | undefined)) | null | undefined, options?: RequestOptions): PagePromise<AgentsPage, Agent>;
    list(options?: {
        [K in 'headers' | 'maxRetries' | 'timeout' | 'signal' | 'idempotencyKey' | 'query']?: RequestOptions[K];
    } & {
        [K in 'method' | 'path' | 'body' | 'stream' | 'httpAgent' | 'fetchOptions' | 'defaultBaseURL' | '__metadata' | '__binaryRequest' | '__binaryResponse' | '__streamClass' | '__streamMode' | '__security' | '__synthesizeEventData']?: never;
    }): PagePromise<AgentsPage, Agent>;
    /**
     * Deletes a reusable agent. See
     * [agent configuration](https://developers.openai.com/api/docs/guides/agents-api/configuration).
     *
     * @example
     * ```ts
     * const agentDeleted = await client.beta.agents.delete(
     *   'agent_id',
     * );
     * ```
     */
    delete(agentID: string, options?: RequestOptions): APIPromise<AgentDeleted>;
}
export type AgentsPage = CursorPage<Agent>;
export type AgentSessionsPage = CursorPage<AgentSession>;
export type SubagentsPage = CursorPage<Subagent>;
export type AgentSessionItemsPage = CursorPage<AgentSessionItem>;
/**
 * A reusable agent scoped to the caller's project.
 */
export interface Agent {
    /**
     * The ID of the reusable agent.
     */
    id: string;
    /**
     * The Unix timestamp, in seconds, when the agent was created.
     */
    created_at: number;
    /**
     * Custom instructions appended to the agent's default base instructions.
     */
    instructions: string | null;
    /**
     * Custom string key-value pairs attached to the agent.
     */
    metadata: {
        [key: string]: string;
    };
    /**
     * The requested model name used for inference.
     */
    model: string;
    /**
     * The resolved configuration for creating and coordinating subagents.
     */
    multi_agent: MultiAgentConfig;
    /**
     * A human-readable name for the agent, or null if it is unnamed.
     */
    name: string | null;
    /**
     * The object type. Always `agent`.
     */
    object: 'agent';
    /**
     * The resolved reasoning configuration, including the model default for an omitted
     * effort.
     */
    reasoning: AgentReasoning;
    /**
     * The resolved service-tier policy used for model requests.
     */
    service_tier: 'auto' | 'default' | 'flex' | 'priority' | 'fast' | 'ultrafast';
    /**
     * The resolved configuration for text generated by the agent.
     */
    text: AgentText;
    /**
     * Tools available to the agent.
     */
    tools: Array<PersistedAgentTool>;
    /**
     * The Unix timestamp, in seconds, when the agent was last updated.
     */
    updated_at: number;
    /**
     * The effective context compaction settings.
     */
    compaction?: Agent.Compaction;
    /**
     * The effective experimental settings for the agent.
     */
    experimental?: Agent.Experimental;
}
export declare namespace Agent {
    /**
     * The effective context compaction settings.
     */
    interface Compaction {
        /**
         * Whether context is compacted in the background. Defaults to false.
         */
        async: boolean;
    }
    /**
     * The effective experimental settings for the agent.
     */
    interface Experimental {
        /**
         * Whether the model receives periodic current-time reminders.
         */
        time_awareness: boolean;
    }
}
export interface AgentBrowserAuthenticationCancelParam {
    action: 'cancel';
    type: 'browser_authentication';
}
export interface AgentBrowserAuthenticationSubmitParam {
    action: 'submit';
    /**
     * Values for up to six active fields in the required action. The submitted
     * field-value mapping and selected option must fit within 120 KiB of JSON.
     */
    fields: Array<AgentBrowserAuthenticationSubmitParam.Field>;
    type: 'browser_authentication';
    /**
     * The chosen method. Required when the required action contains options.
     */
    selected_option?: string | null;
}
export declare namespace AgentBrowserAuthenticationSubmitParam {
    /**
     * One user-entered value, including non-password fields such as an email address.
     */
    interface Field {
        /**
         * The field ID from the required action.
         */
        field_id: string;
        /**
         * The value to enter into the registered control.
         */
        value: string;
    }
}
export interface AgentBrowserOriginAccessParam {
    /**
     * Whether to allow, deny, or cancel the requested origin access.
     *
     * - `approve` - Allow the browser to access this origin.
     * - `deny` - Deny access to this origin.
     * - `cancel` - Dismiss this request without approving access.
     */
    decision: 'approve' | 'deny' | 'cancel';
    type: 'browser_origin_access';
}
/**
 * A request to close a subagent.
 */
export interface AgentCloseSubagentCallItem {
    /**
     * The ID of the tool call item.
     */
    id: string;
    /**
     * The ID of the agent to close.
     */
    recipient_agent_id: string;
    /**
     * The ID of the agent requesting the close.
     */
    sender_agent_id: string;
    /**
     * The status of the tool call.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `close_subagent_call`.
     */
    type: 'close_subagent_call';
}
/**
 * A command execution produced by the agent.
 */
export interface AgentCommandExecutionItem {
    /**
     * The ID of the command execution item.
     */
    id: string;
    /**
     * The command that was executed.
     */
    command: string;
    /**
     * The working directory used to execute the command.
     */
    cwd: string | null;
    /**
     * The command duration in milliseconds.
     */
    duration_ms: number | null;
    /**
     * The process exit code, if the command completed.
     */
    exit_code: number | null;
    /**
     * The command output, if available.
     */
    output: string | null;
    /**
     * The status of the command execution.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `command_execution`.
     */
    type: 'command_execution';
}
/**
 * A plaintext or encrypted content part exchanged between agents.
 */
export type AgentContent = OutputText | AgentContent.EncryptedContentResource;
export declare namespace AgentContent {
    /**
     * Encrypted content exchanged between agents.
     */
    interface EncryptedContentResource {
        /**
         * The encrypted content payload.
         */
        encrypted_content: string;
        /**
         * The content type. Always `encrypted_content`.
         */
        type: 'encrypted_content';
    }
}
/**
 * A request to spawn a subagent.
 */
export interface AgentCreateSubagentCallItem {
    /**
     * The ID of the tool call item.
     */
    id: string;
    /**
     * The ID of the agent that requested the subagent.
     */
    agent_id: string;
    /**
     * The task given to the spawned agent.
     */
    content: Array<AgentContent>;
    /**
     * The model requested for the spawned agent.
     */
    model: string | null;
    /**
     * The reasoning effort requested for the spawned agent.
     */
    reasoning_effort: string | null;
    /**
     * The status of the tool call.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `create_subagent_call`.
     */
    type: 'create_subagent_call';
}
/**
 * A deleted reusable agent.
 */
export interface AgentDeleted {
    /**
     * The ID of the deleted agent.
     */
    id: string;
    /**
     * Whether the agent was deleted. Always `true`.
     */
    deleted: boolean;
    /**
     * The object type. Always `agent.deleted`.
     */
    object: 'agent.deleted';
}
/**
 * A function call produced by the agent.
 */
export interface AgentFunctionCallItem {
    /**
     * The ID of the function call item.
     */
    id: string;
    /**
     * The arguments to pass to the function.
     */
    arguments: unknown;
    /**
     * The ID used to submit the function result.
     */
    call_id: string;
    /**
     * The name of the function to call.
     */
    name: string;
    /**
     * The status of the function call.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `function_call`.
     */
    type: 'function_call';
}
/**
 * The text or model-input content supplied as a function result.
 */
export type AgentFunctionCallOutput = string | Array<InputContent>;
/**
 * A function result represented as text or supported model-input content.
 */
export type AgentFunctionCallOutputParam = string | Array<InputContentParam>;
/**
 * The status of a tool call.
 *
 * - `in_progress` - The call is in progress.
 * - `completed` - The call completed successfully.
 * - `failed` - The call failed.
 * - `incomplete` - The call stopped before completing.
 */
export type AgentFunctionCallStatus = 'in_progress' | 'completed' | 'failed' | 'incomplete';
/**
 * A request to interrupt a subagent's current turn. The subagent remains
 * available.
 */
export interface AgentInterruptSubagentCallItem {
    /**
     * The ID of the tool call item.
     */
    id: string;
    /**
     * The ID of the agent to interrupt.
     */
    recipient_agent_id: string;
    /**
     * The ID of the agent requesting the interrupt.
     */
    sender_agent_id: string;
    /**
     * The status of the tool call.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `interrupt_subagent_call`.
     */
    type: 'interrupt_subagent_call';
}
/**
 * A call to a tool on an MCP server.
 */
export interface AgentMcpCallItem {
    /**
     * The ID of the MCP call item.
     */
    id: string;
    /**
     * The arguments passed to the MCP tool.
     */
    arguments: unknown;
    /**
     * The error returned by the MCP tool, if any.
     */
    error: unknown;
    /**
     * The name of the MCP tool.
     */
    name: string;
    /**
     * The output returned by the MCP tool, if any.
     */
    output: unknown;
    /**
     * The label of the MCP server.
     */
    server_label: string;
    /**
     * The status of the MCP tool call.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `mcp_call`.
     */
    type: 'mcp_call';
}
/**
 * Emitted when command execution produces an output delta.
 */
export interface AgentOutputCommandExecutionOutputDeltaEvent {
    /**
     * The output text that was appended.
     */
    delta: string;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the command execution item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.output.command_execution_output.delta`.
     */
    type: 'agent.output.command_execution_output.delta';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * An output item produced by an agent.
 */
export type AgentOutputItem = AgentSessionAssistantMessage | AgentReasoningItem | AgentFunctionCallItem | AgentMcpCallItem | AgentOutputItem.ComputerUseCallItemResource | AgentOutputItem.BrowserAuthenticationRequestItemResource | AgentWebSearchCallItem | AgentCommandExecutionItem | AgentCreateSubagentCallItem | AgentSendSubagentInputCallItem | AgentResumeSubagentCallItem | AgentWaitForSubagentsCallItem | AgentInterruptSubagentCallItem | AgentCloseSubagentCallItem;
export declare namespace AgentOutputItem {
    /**
     * One execution of the platform-provided computer-use capability.
     */
    interface ComputerUseCallItemResource {
        /**
         * The ID of the activity item.
         */
        id: string;
        /**
         * The last screenshot emitted by the model. Null when screenshot inclusion is
         * disabled or the call emitted no screenshot.
         */
        output: ComputerUseCallItemResource.Output | null;
        /**
         * The execution status of the activity.
         */
        status: AgentsAPI.AgentFunctionCallStatus;
        /**
         * A model-generated description of the activity, when available.
         */
        title: string | null;
        /**
         * The ID of the turn that contains this item.
         */
        turn_id: string;
        /**
         * The item type. Always `computer_use_call`.
         */
        type: 'computer_use_call';
    }
    namespace ComputerUseCallItemResource {
        /**
         * The last screenshot emitted by the model. Null when screenshot inclusion is
         * disabled or the call emitted no screenshot.
         */
        interface Output {
            /**
             * The complete JPEG image as a base64 data URL.
             */
            image_url: string;
            /**
             * The content type. Always `computer_screenshot`.
             */
            type: 'computer_screenshot';
        }
    }
    /**
     * A credential-free history record of the emitted login request.
     */
    interface BrowserAuthenticationRequestItemResource {
        /**
         * The stable history item ID.
         */
        id: string;
        /**
         * A registered form awaiting the application's response.
         */
        request: BrowserAuthenticationRequestItemResource.Request;
        request_id: string;
        turn_id: string;
        /**
         * The item type. Always computer_use_approval_request.
         */
        type: 'computer_use_approval_request';
    }
    namespace BrowserAuthenticationRequestItemResource {
        /**
         * A registered form awaiting the application's response.
         */
        interface Request {
            /**
             * The registered form or frame origin where values will be entered.
             */
            credential_origin: string | null;
            /**
             * Controls to render. All submitted values are sensitive.
             */
            fields: Array<Request.Field>;
            /**
             * Sign-in methods. Empty for a plain form.
             */
            options: Array<Request.Option>;
            /**
             * Why the agent needs the user to sign in.
             */
            reason: string | null;
            /**
             * The type of the object. Always `browser_authentication`.
             */
            type: 'browser_authentication';
        }
        namespace Request {
            /**
             * A control in a registered browser-login form.
             */
            interface Field {
                /**
                 * The field ID to submit as field_id in a fields entry.
                 */
                id: string;
                /**
                 * The label to display beside the control.
                 */
                label: string;
                /**
                 * Whether this control requires a nonempty value.
                 */
                required: boolean;
                /**
                 * The rendering type, such as email, password, or text.
                 */
                type: string;
            }
            /**
             * A sign-in method and the fields that belong to it.
             */
            interface Option {
                /**
                 * The option ID to submit as selected_option.
                 */
                id: string;
                /**
                 * IDs from the registered fields that this method accepts.
                 */
                field_ids: Array<string>;
                /**
                 * The method label to display.
                 */
                label: string;
            }
        }
    }
}
/**
 * The status of an agent output item.
 *
 * - `in_progress` - The item is in progress.
 * - `completed` - The item is complete.
 * - `incomplete` - The item stopped before completing.
 */
export type AgentOutputItemStatus = 'in_progress' | 'completed' | 'incomplete';
/**
 * The reasoning configuration used by an agent.
 */
export interface AgentReasoning {
    /**
     * The requested reasoning effort, or `null` when the model selects its own
     * default.
     */
    effort: 'none' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max' | null;
    /**
     * The requested reasoning summary format, or `null` when summaries are disabled.
     *
     * - `concise` - Returns a concise reasoning summary when supported.
     * - `detailed` - Returns a detailed reasoning summary when supported.
     * - `auto` - Automatically selects the most detailed summary supported by the
     *   model.
     */
    summary: 'concise' | 'detailed' | 'auto' | null;
}
/**
 * A reasoning item produced by the agent.
 */
export interface AgentReasoningItem {
    /**
     * The ID of the reasoning item.
     */
    id: string;
    /**
     * The status of the reasoning item.
     */
    status: AgentOutputItemStatus | null;
    /**
     * The reasoning summaries produced by the agent.
     */
    summary: Array<SummaryText>;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `reasoning`.
     */
    type: 'reasoning';
}
/**
 * Reasoning configuration for the agent.
 */
export interface AgentReasoningParam {
    /**
     * The amount of reasoning effort the model should use. Omission lets the model
     * select it.
     */
    effort?: 'none' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max' | null;
    /**
     * Controls whether the response includes a reasoning summary.
     *
     * - `concise` - Returns a concise reasoning summary when supported.
     * - `detailed` - Returns a detailed reasoning summary when supported.
     * - `auto` - Automatically selects the most detailed summary supported by the
     *   model.
     */
    summary?: 'concise' | 'detailed' | 'auto' | null;
}
/**
 * A request to resume a subagent.
 */
export interface AgentResumeSubagentCallItem {
    /**
     * The ID of the tool call item.
     */
    id: string;
    /**
     * The ID of the agent to resume.
     */
    recipient_agent_id: string;
    /**
     * The ID of the agent requesting the resume.
     */
    sender_agent_id: string;
    /**
     * The status of the tool call.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `resume_subagent_call`.
     */
    type: 'resume_subagent_call';
}
/**
 * A request to send input to another agent.
 */
export interface AgentSendSubagentInputCallItem {
    /**
     * The ID of the tool call item.
     */
    id: string;
    /**
     * The input sent to the receiving agent.
     */
    content: Array<AgentContent>;
    /**
     * The ID of the agent receiving the input.
     */
    recipient_agent_id: string;
    /**
     * The ID of the agent sending the input.
     */
    sender_agent_id: string;
    /**
     * The status of the tool call.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `send_subagent_input_call`.
     */
    type: 'send_subagent_input_call';
}
/**
 * A Managed Agents session.
 */
export interface AgentSession {
    /**
     * The ID of the session.
     */
    id: string;
    /**
     * The agent running in the session.
     */
    agent: AgentSession.Agent;
    /**
     * The Unix timestamp, in seconds, when the session was created.
     */
    created_at: number;
    /**
     * The execution environment for the session.
     */
    environment: Environment;
    /**
     * The error that caused the session to fail, if any.
     */
    error: string | null;
    /**
     * The Unix timestamp, in seconds, when the session was last active.
     */
    last_active_at: number;
    /**
     * Custom string key-value pairs attached to the session.
     */
    metadata: {
        [key: string]: string;
    };
    /**
     * The object type. Always `agent.session`.
     */
    object: 'agent.session';
    /**
     * Actions that must be completed before the session can continue.
     */
    required_actions: Array<AgentSession.SessionRequiredActionResourceMcpApprovalRequest | AgentSession.SessionRequiredActionResourceComputerUseApprovalRequest | AgentSession.SessionRequiredActionResourceFunctionCall | AgentSession.SessionRequiredActionResourceEnvironmentConnection>;
    /**
     * The current status of the session.
     *
     * - `idle` - The session has no turn in progress and is ready for input. A hosted
     *   environment may still be provisioning.
     * - `in_progress` - The session is processing a turn.
     * - `requires_action` - The session is waiting for one or more required actions.
     * - `failed` - The session failed.
     * - `budget_reached` - The session is paused because its spending limit was
     *   reached.
     */
    status: 'idle' | 'in_progress' | 'requires_action' | 'failed' | 'budget_reached';
    /**
     * Best-effort token usage for the session, or null if unknown. Recorded usage may
     * change.
     */
    usage: TokenUsage | null;
    /**
     * The IDs of vaults made available to the session.
     */
    vault_ids: Array<string>;
    /**
     * Default prompt cache lifetime for turns in this session, when configured.
     */
    prompt_cache_options?: AgentSession.PromptCacheOptions | null;
    /**
     * Review applied to eligible actions in this session. Omitted when review is none
     * and automatic review is not enabled. Omission means none.
     */
    review?: 'none' | 'auto_review';
    /**
     * Spending limit and best-effort consumption, in USD cents. Present when
     * spending-control visibility is enabled; limit is null without a cap. Older
     * server responses may omit this object.
     */
    spend_control?: AgentSession.SpendControl;
}
export declare namespace AgentSession {
    /**
     * The agent running in the session.
     */
    interface Agent {
        /**
         * The ID of the agent.
         */
        id: string;
        /**
         * Custom instructions appended to the agent's default base instructions.
         */
        instructions: string | null;
        /**
         * The model used by the agent.
         */
        model: string;
        /**
         * Configuration for creating and coordinating subagents.
         */
        multi_agent: AgentsAPI.MultiAgentConfig;
        /**
         * The reusable agent's name when the session was created, or null if no name was
         * saved. Later changes to the agent's name do not affect this value.
         */
        name: string | null;
        /**
         * The agent's reasoning configuration.
         */
        reasoning: AgentsAPI.AgentReasoning;
        /**
         * The effective service-tier policy for model requests. Defaults to `auto`.
         */
        service_tier: 'auto' | 'default' | 'flex' | 'priority' | 'fast' | 'ultrafast';
        /**
         * Configuration for text generated by the agent.
         */
        text: AgentsAPI.AgentText;
        /**
         * Tools available to the agent.
         */
        tools: Array<AgentsAPI.AgentTool>;
        /**
         * The effective context compaction settings.
         */
        compaction?: Agent.Compaction;
        /**
         * The effective experimental settings for the agent.
         */
        experimental?: Agent.Experimental;
    }
    namespace Agent {
        /**
         * The effective context compaction settings.
         */
        interface Compaction {
            /**
             * Whether context is compacted in the background. Defaults to false.
             */
            async: boolean;
        }
        /**
         * The effective experimental settings for the agent.
         */
        interface Experimental {
            /**
             * Whether the model receives periodic current-time reminders.
             */
            time_awareness: boolean;
        }
    }
    /**
     * Respond to an MCP tool-call approval request.
     */
    interface SessionRequiredActionResourceMcpApprovalRequest {
        /**
         * Information for presenting an MCP approval.
         */
        request: SessionRequiredActionResourceMcpApprovalRequest.Request;
        /**
         * The opaque approval ID to echo when responding.
         */
        request_id: string;
        /**
         * The turn that requested approval.
         */
        turn_id: string;
        /**
         * The type of the object. Always `mcp_approval_request`.
         */
        type: 'mcp_approval_request';
    }
    namespace SessionRequiredActionResourceMcpApprovalRequest {
        /**
         * Information for presenting an MCP approval.
         */
        interface Request {
            /**
             * The tool arguments as JSON, or null when CCA does not provide them.
             */
            arguments: unknown;
            message: string;
            /**
             * The tool name, or null when CCA does not provide it.
             */
            name: string | null;
            server_label: string;
            /**
             * The type of the object. Always `mcp_tool_call`.
             */
            type: 'mcp_tool_call';
        }
    }
    /**
     * Respond to a computer-use request.
     */
    interface SessionRequiredActionResourceComputerUseApprovalRequest {
        /**
         * The information needed to render the request.
         */
        request: SessionRequiredActionResourceComputerUseApprovalRequest.ComputerUseApprovalRequestKindResourceBrowserAuthentication | SessionRequiredActionResourceComputerUseApprovalRequest.ComputerUseApprovalRequestKindResourceBrowserOriginAccess;
        /**
         * The registered request ID to echo when responding.
         */
        request_id: string;
        /**
         * The turn that requested approval.
         */
        turn_id: string;
        /**
         * The type of the object. Always `computer_use_approval_request`.
         */
        type: 'computer_use_approval_request';
    }
    namespace SessionRequiredActionResourceComputerUseApprovalRequest {
        /**
         * A registered form awaiting the application's response.
         */
        interface ComputerUseApprovalRequestKindResourceBrowserAuthentication {
            /**
             * The registered form or frame origin where values will be entered.
             */
            credential_origin: string | null;
            /**
             * Controls to render. All submitted values are sensitive.
             */
            fields: Array<ComputerUseApprovalRequestKindResourceBrowserAuthentication.Field>;
            /**
             * Sign-in methods. Empty for a plain form.
             */
            options: Array<ComputerUseApprovalRequestKindResourceBrowserAuthentication.Option>;
            /**
             * Why the agent needs the user to sign in.
             */
            reason: string | null;
            /**
             * The type of the object. Always `browser_authentication`.
             */
            type: 'browser_authentication';
        }
        namespace ComputerUseApprovalRequestKindResourceBrowserAuthentication {
            /**
             * A control in a registered browser-login form.
             */
            interface Field {
                /**
                 * The field ID to submit as field_id in a fields entry.
                 */
                id: string;
                /**
                 * The label to display beside the control.
                 */
                label: string;
                /**
                 * Whether this control requires a nonempty value.
                 */
                required: boolean;
                /**
                 * The rendering type, such as email, password, or text.
                 */
                type: string;
            }
            /**
             * A sign-in method and the fields that belong to it.
             */
            interface Option {
                /**
                 * The option ID to submit as selected_option.
                 */
                id: string;
                /**
                 * IDs from the registered fields that this method accepts.
                 */
                field_ids: Array<string>;
                /**
                 * The method label to display.
                 */
                label: string;
            }
        }
        /**
         * A browser origin awaiting the application's approval decision.
         */
        interface ComputerUseApprovalRequestKindResourceBrowserOriginAccess {
            /**
             * The origin the browser needs permission to access.
             */
            origin: string;
            /**
             * The browser's explanation for this request, or null when unavailable.
             */
            reason: string | null;
            /**
             * The type of the object. Always `browser_origin_access`.
             */
            type: 'browser_origin_access';
        }
    }
    /**
     * Run a function tool and submit its result.
     */
    interface SessionRequiredActionResourceFunctionCall {
        /**
         * The arguments supplied by the model.
         */
        arguments: unknown;
        /**
         * The ID to include when submitting the function result.
         */
        call_id: string;
        /**
         * The function name.
         */
        name: string;
        /**
         * The ID of the turn that requested the function call.
         */
        turn_id: string;
        /**
         * The type of the object. Always `function_call`.
         */
        type: 'function_call';
    }
    /**
     * Reconnect a session environment.
     */
    interface SessionRequiredActionResourceEnvironmentConnection {
        /**
         * The ID of the environment to reconnect.
         */
        environment_id: string;
        /**
         * The type of the object. Always `environment_connection`.
         */
        type: 'environment_connection';
    }
    /**
     * Default prompt cache lifetime for turns in this session, when configured.
     */
    interface PromptCacheOptions {
        ttl: '30m' | '12h';
    }
    /**
     * Spending limit and best-effort consumption, in USD cents. Present when
     * spending-control visibility is enabled; limit is null without a cap. Older
     * server responses may omit this object.
     */
    interface SpendControl {
        /**
         * Best-effort recorded spend floored to whole USD cents, or null when unavailable.
         */
        consumed: number | null;
        /**
         * The configured positive limit in USD cents, or null when unlimited.
         */
        limit: number | null;
    }
}
/**
 * An assistant message produced by the agent.
 */
export interface AgentSessionAssistantMessage {
    /**
     * The ID of the message.
     */
    id: string;
    /**
     * The content of the message.
     */
    content: Array<OutputText>;
    /**
     * The phase of the assistant message.
     *
     * - `commentary` - Commentary produced while the agent works.
     * - `final_answer` - The agent's final answer.
     */
    phase: 'commentary' | 'final_answer' | null;
    /**
     * The role of the message author. Always `assistant`.
     */
    role: 'assistant';
    /**
     * The status of the message.
     */
    status: AgentOutputItemStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `message`.
     */
    type: 'message';
}
/**
 * Emitted when a session pauses because its spending limit was reached.
 */
export interface AgentSessionBudgetReachedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The paused session.
     */
    session: AgentSession;
    /**
     * The type of the object. Always `agent.session.budget_reached`.
     */
    type: 'agent.session.budget_reached';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a session is created.
 */
export interface AgentSessionCreatedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The session that was created.
     */
    session: AgentSession;
    /**
     * The type of the object. Always `agent.session.created`.
     */
    type: 'agent.session.created';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * A Managed Agents session removed from the public API. Physical cleanup may
 * continue asynchronously.
 */
export interface AgentSessionDeleted {
    /**
     * The ID of the deleted session.
     */
    id: string;
    /**
     * Whether the session has been removed from the public API. Always `true`.
     * Physical cleanup may still be in progress.
     */
    deleted: boolean;
    /**
     * The object type. Always `agent.session.deleted`.
     */
    object: 'agent.session.deleted';
}
/**
 * Emitted when a session environment connects.
 */
export interface AgentSessionEnvironmentConnectedEvent {
    /**
     * The current environment state.
     */
    environment: AgentSessionEnvironmentState;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.environment.connected`.
     */
    type: 'agent.session.environment.connected';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a session environment disconnects.
 */
export interface AgentSessionEnvironmentDisconnectedEvent {
    /**
     * The current environment state.
     */
    environment: AgentSessionEnvironmentState;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.environment.disconnected`.
     */
    type: 'agent.session.environment.disconnected';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted after a suspended hosted session environment and its checkpoint expire.
 */
export interface AgentSessionEnvironmentExpiredEvent {
    /**
     * The current environment state.
     */
    environment: AgentSessionEnvironmentState;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.environment.expired`.
     */
    type: 'agent.session.environment.expired';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a session environment fails.
 */
export interface AgentSessionEnvironmentFailedEvent {
    /**
     * The current environment state.
     */
    environment: AgentSessionEnvironmentState;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.environment.failed`.
     */
    type: 'agent.session.environment.failed';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted while a session environment is being prepared.
 */
export interface AgentSessionEnvironmentPendingEvent {
    /**
     * The current environment state.
     */
    environment: AgentSessionEnvironmentState;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.environment.pending`.
     */
    type: 'agent.session.environment.pending';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a hosted session environment is ready to connect.
 */
export interface AgentSessionEnvironmentReadyEvent {
    /**
     * The current environment state.
     */
    environment: AgentSessionEnvironmentState;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.environment.ready`.
     */
    type: 'agent.session.environment.ready';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted after a hosted sandbox is replaced. Conversation history survives;
 * changes to the previous sandbox's files and processes do not.
 */
export interface AgentSessionEnvironmentResetEvent {
    /**
     * The stable environment ID, retained across sandbox replacements.
     */
    environment_id: string;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * Monotonically increasing reset number. Repeated notifications share this number.
     */
    reset_count: number;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The associated turn, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.environment.reset`.
     */
    type: 'agent.session.environment.reset';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * The current state of a session environment.
 */
export interface AgentSessionEnvironmentState {
    /**
     * The public ID of the environment.
     */
    id: string;
    /**
     * The error reported while preparing the environment, if any.
     */
    error: AgentSessionEnvironmentState.Error | null;
    /**
     * The environment's connection status.
     *
     * - `pending` - The environment is being prepared.
     * - `ready` - The environment is ready to connect.
     * - `connected` - The environment is connected.
     * - `disconnected` - The environment is disconnected.
     * - `suspended` - The environment is stopped and can be resumed from its private
     *   checkpoint.
     * - `expired` - The environment and its private checkpoint have expired.
     * - `failed` - The environment failed to connect.
     */
    status: 'pending' | 'ready' | 'connected' | 'disconnected' | 'suspended' | 'expired' | 'failed';
    /**
     * The environment type.
     */
    type: string;
}
export declare namespace AgentSessionEnvironmentState {
    /**
     * The error reported while preparing the environment, if any.
     */
    interface Error {
        /**
         * A machine-readable error code.
         */
        code: string;
        /**
         * A human-readable error message.
         */
        message: string;
        /**
         * The error type.
         */
        type: string;
    }
}
/**
 * Emitted after an idle hosted session environment is checkpointed and stopped.
 */
export interface AgentSessionEnvironmentSuspendedEvent {
    /**
     * The current environment state.
     */
    environment: AgentSessionEnvironmentState;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.environment.suspended`.
     */
    type: 'agent.session.environment.suspended';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a turn or session fails.
 */
export interface AgentSessionErrorEvent {
    /**
     * The error that occurred.
     */
    error: SessionError;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The type of the object. Always `error`.
     */
    type: 'error';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * An event emitted by a Managed Agents session.
 */
export type AgentSessionEvent = AgentSessionErrorEvent | AgentSessionEnvironmentReadyEvent | AgentSessionEnvironmentSuspendedEvent | AgentSessionEnvironmentExpiredEvent | AgentSessionEnvironmentResetEvent | AgentOutputCommandExecutionOutputDeltaEvent | AgentSessionCreatedEvent | AgentSessionTurnCreatedEvent | AgentSessionTurnInProgressEvent | AgentSessionTurnCompletedEvent | AgentSessionTurnFailedEvent | AgentSessionTurnCancelledEvent | AgentSessionTurnItemAddedEvent | AgentSessionIdleEvent | AgentSessionBudgetReachedEvent | AgentSessionInProgressEvent | AgentSessionRequiresActionEvent | AgentSessionFailedEvent | AgentSessionEnvironmentPendingEvent | AgentSessionEnvironmentConnectedEvent | AgentSessionEnvironmentDisconnectedEvent | AgentSessionEnvironmentFailedEvent | AgentSessionSubagentCreatedEvent | AgentSessionSubagentActiveEvent | AgentSessionSubagentClosedEvent | AgentSessionTurnItemDoneEvent | AgentSessionTurnContentPartAddedEvent | AgentSessionTurnContentPartDoneEvent | AgentSessionTurnOutputTextDeltaEvent | AgentSessionTurnOutputTextDoneEvent | AgentSessionTurnReasoningSummaryPartAddedEvent | AgentSessionTurnReasoningSummaryPartDoneEvent | AgentSessionTurnReasoningSummaryTextDeltaEvent | AgentSessionTurnReasoningSummaryTextDoneEvent;
/**
 * Emitted when a session fails.
 */
export interface AgentSessionFailedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The failed session.
     */
    session: AgentSession;
    /**
     * The type of the object. Always `agent.session.failed`.
     */
    type: 'agent.session.failed';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a session becomes idle.
 */
export interface AgentSessionIdleEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The session that became idle.
     */
    session: AgentSession;
    /**
     * The type of the object. Always `agent.session.idle`.
     */
    type: 'agent.session.idle';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a session starts processing a turn.
 */
export interface AgentSessionInProgressEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The session that started processing.
     */
    session: AgentSession;
    /**
     * The type of the object. Always `agent.session.in_progress`.
     */
    type: 'agent.session.in_progress';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * A user message submitted to a session.
 */
export interface AgentSessionInputMessageParam {
    /**
     * The content of the message.
     */
    content: Array<InputContentParam>;
    /**
     * The role of the message author. Always `user`.
     */
    role: 'user';
    /**
     * The type of the input item. Always `message`.
     */
    type?: 'message';
}
/**
 * Input submitted to an existing session.
 */
export type AgentSessionInputParam = AgentSessionInputParam.SessionInputParamAgentSessionInputMcpApprovalRequestResult | AgentSessionInputParam.SessionInputParamAgentSessionInputComputerUseApprovalRequestResult | AgentSessionInputParam.SessionInputParamAgentSessionInputMessage | AgentSessionInputParam.SessionInputParamAgentSessionInputCancel | AgentSessionInputParam.SessionInputParamAgentSessionInputToolResult;
export declare namespace AgentSessionInputParam {
    /**
     * Responds to a pending MCP tool-call approval request.
     */
    interface SessionInputParamAgentSessionInputMcpApprovalRequestResult {
        /**
         * The opaque approval ID from the required action.
         */
        request_id: string;
        /**
         * The user's decision for a pending MCP tool call.
         */
        response: SessionInputParamAgentSessionInputMcpApprovalRequestResult.Response;
        /**
         * The type of the object. Always
         * `agent.session.input.mcp_approval_request_result`.
         */
        type: 'agent.session.input.mcp_approval_request_result';
    }
    namespace SessionInputParamAgentSessionInputMcpApprovalRequestResult {
        /**
         * The user's decision for a pending MCP tool call.
         */
        interface Response {
            /**
             * Cancel dismisses this request without cancelling the session or turn.
             */
            decision: 'approve' | 'deny' | 'cancel';
            /**
             * The type of the object. Always `mcp_tool_call`.
             */
            type: 'mcp_tool_call';
        }
    }
    /**
     * Responds to a pending Computer Use approval request.
     */
    interface SessionInputParamAgentSessionInputComputerUseApprovalRequestResult {
        /**
         * The registered request ID from the required action.
         */
        request_id: string;
        /**
         * The response for this request type.
         */
        response: AgentsAPI.AgentBrowserAuthenticationSubmitParam | AgentsAPI.AgentBrowserAuthenticationCancelParam | AgentsAPI.AgentBrowserOriginAccessParam;
        /**
         * The type of the object. Always
         * `agent.session.input.computer_use_approval_request_result`.
         */
        type: 'agent.session.input.computer_use_approval_request_result';
    }
    /**
     * Adds one or more user messages and starts a turn.
     */
    interface SessionInputParamAgentSessionInputMessage {
        /**
         * The user messages to add to the session.
         */
        input: Array<AgentsAPI.AgentSessionInputMessageParam>;
        /**
         * The type of the object. Always `agent.session.input.message`.
         */
        type: 'agent.session.input.message';
    }
    /**
     * Cancels the session's active turn.
     */
    interface SessionInputParamAgentSessionInputCancel {
        /**
         * The type of the object. Always `agent.session.input.cancel`.
         */
        type: 'agent.session.input.cancel';
    }
    /**
     * Submits the result of a function call.
     */
    interface SessionInputParamAgentSessionInputToolResult {
        /**
         * The ID of the function call.
         */
        call_id: string;
        /**
         * Whether the function call succeeded.
         */
        success: boolean;
        /**
         * The ID of the turn that requested the function call.
         */
        turn_id: string;
        /**
         * The type of the object. Always `agent.session.input.tool_result`.
         */
        type: 'agent.session.input.tool_result';
        /**
         * The error message when the call failed.
         */
        error?: string | null;
        /**
         * The function result when the call succeeded.
         */
        output?: AgentsAPI.AgentFunctionCallOutputParam | null;
    }
}
/**
 * An item associated with a session turn.
 */
export type AgentSessionItem = AgentSessionMessage | AgentReasoningItem | AgentFunctionCallItem | AgentSessionItem.FunctionCallOutputItemResource | AgentSessionItem.AgentMessageItemResource | AgentMcpCallItem | AgentSessionItem.ComputerUseCallItemResource | AgentSessionItem.BrowserAuthenticationRequestItemResource | AgentSessionItem.ComputerUseApprovalRequestResultItemResource | AgentWebSearchCallItem | AgentCommandExecutionItem | AgentCreateSubagentCallItem | AgentSendSubagentInputCallItem | AgentResumeSubagentCallItem | AgentWaitForSubagentsCallItem | AgentInterruptSubagentCallItem | AgentCloseSubagentCallItem;
export declare namespace AgentSessionItem {
    /**
     * The result supplied for a function call.
     */
    interface FunctionCallOutputItemResource {
        /**
         * The ID of the function call output item.
         */
        id: string;
        /**
         * The ID of the function call that produced this output.
         */
        call_id: string;
        /**
         * The error message, if the call failed.
         */
        error: string | null;
        /**
         * The function result, if the call succeeded.
         */
        output: AgentsAPI.AgentFunctionCallOutput | null;
        /**
         * The status of the function call.
         */
        status: AgentsAPI.AgentFunctionCallStatus;
        /**
         * The ID of the turn that contains this item.
         */
        turn_id: string;
        /**
         * The item type. Always `function_call_output`.
         */
        type: 'function_call_output';
    }
    /**
     * A message exchanged between agent threads.
     */
    interface AgentMessageItemResource {
        /**
         * The ID of the message.
         */
        id: string;
        /**
         * The content exchanged between the agents.
         */
        content: Array<AgentsAPI.AgentContent>;
        /**
         * The ID or name of the receiving agent.
         */
        recipient_agent_id: string;
        /**
         * The ID or name of the sending agent.
         */
        sender_agent_id: string;
        /**
         * The ID of the turn that contains this item.
         */
        turn_id: string;
        /**
         * The item type. Always `agent_message`.
         */
        type: 'agent_message';
    }
    /**
     * One execution of the platform-provided computer-use capability.
     */
    interface ComputerUseCallItemResource {
        /**
         * The ID of the activity item.
         */
        id: string;
        /**
         * The last screenshot emitted by the model. Null when screenshot inclusion is
         * disabled or the call emitted no screenshot.
         */
        output: ComputerUseCallItemResource.Output | null;
        /**
         * The execution status of the activity.
         */
        status: AgentsAPI.AgentFunctionCallStatus;
        /**
         * A model-generated description of the activity, when available.
         */
        title: string | null;
        /**
         * The ID of the turn that contains this item.
         */
        turn_id: string;
        /**
         * The item type. Always `computer_use_call`.
         */
        type: 'computer_use_call';
    }
    namespace ComputerUseCallItemResource {
        /**
         * The last screenshot emitted by the model. Null when screenshot inclusion is
         * disabled or the call emitted no screenshot.
         */
        interface Output {
            /**
             * The complete JPEG image as a base64 data URL.
             */
            image_url: string;
            /**
             * The content type. Always `computer_screenshot`.
             */
            type: 'computer_screenshot';
        }
    }
    /**
     * A credential-free history record of the emitted login request.
     */
    interface BrowserAuthenticationRequestItemResource {
        /**
         * The stable history item ID.
         */
        id: string;
        /**
         * A registered form awaiting the application's response.
         */
        request: BrowserAuthenticationRequestItemResource.Request;
        request_id: string;
        turn_id: string;
        /**
         * The item type. Always computer_use_approval_request.
         */
        type: 'computer_use_approval_request';
    }
    namespace BrowserAuthenticationRequestItemResource {
        /**
         * A registered form awaiting the application's response.
         */
        interface Request {
            /**
             * The registered form or frame origin where values will be entered.
             */
            credential_origin: string | null;
            /**
             * Controls to render. All submitted values are sensitive.
             */
            fields: Array<Request.Field>;
            /**
             * Sign-in methods. Empty for a plain form.
             */
            options: Array<Request.Option>;
            /**
             * Why the agent needs the user to sign in.
             */
            reason: string | null;
            /**
             * The type of the object. Always `browser_authentication`.
             */
            type: 'browser_authentication';
        }
        namespace Request {
            /**
             * A control in a registered browser-login form.
             */
            interface Field {
                /**
                 * The field ID to submit as field_id in a fields entry.
                 */
                id: string;
                /**
                 * The label to display beside the control.
                 */
                label: string;
                /**
                 * Whether this control requires a nonempty value.
                 */
                required: boolean;
                /**
                 * The rendering type, such as email, password, or text.
                 */
                type: string;
            }
            /**
             * A sign-in method and the fields that belong to it.
             */
            interface Option {
                /**
                 * The option ID to submit as selected_option.
                 */
                id: string;
                /**
                 * IDs from the registered fields that this method accepts.
                 */
                field_ids: Array<string>;
                /**
                 * The method label to display.
                 */
                label: string;
            }
        }
    }
    /**
     * A credential-free record of an admitted response, not proof of completion.
     */
    interface ComputerUseApprovalRequestResultItemResource {
        /**
         * The stable history item ID.
         */
        id: string;
        /**
         * The registered request answered by this item.
         */
        request_id: string;
        /**
         * The admitted response, without submitted credential values.
         */
        response: ComputerUseApprovalRequestResultItemResource.ComputerUseApprovalResponseKindResourceBrowserAuthenticationSubmitResource | ComputerUseApprovalRequestResultItemResource.ComputerUseApprovalResponseKindResourceBrowserAuthenticationCancelResource;
        /**
         * The ID of the turn that contains this item.
         */
        turn_id: string;
        type: 'computer_use_approval_request_result';
    }
    namespace ComputerUseApprovalRequestResultItemResource {
        interface ComputerUseApprovalResponseKindResourceBrowserAuthenticationSubmitResource {
            action: 'submit';
            /**
             * The chosen sign-in method, or null when no options were offered.
             */
            selected_option: string | null;
            type: 'browser_authentication';
        }
        interface ComputerUseApprovalResponseKindResourceBrowserAuthenticationCancelResource {
            action: 'cancel';
            type: 'browser_authentication';
        }
    }
}
/**
 * A user or assistant message recorded in a session.
 */
export interface AgentSessionMessage {
    /**
     * The ID of this item, or null for legacy user messages whose ID was not recorded.
     */
    id: string | null;
    /**
     * The content of the message. User messages contain input text or images;
     * assistant messages contain output text.
     */
    content: Array<AgentSessionMessageContent>;
    /**
     * The phase of an assistant message. Null for user messages.
     *
     * - `commentary` - Commentary produced while the agent works.
     * - `final_answer` - The agent's final answer.
     */
    phase: 'commentary' | 'final_answer' | null;
    /**
     * The role of the message author.
     */
    role: 'user' | 'assistant';
    /**
     * The status of the message. User messages are always `completed`.
     */
    status: AgentOutputItemStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `message`.
     */
    type: 'message';
}
/**
 * A content part in a session message.
 */
export type AgentSessionMessageContent = AgentSessionMessageContent.MessageContentResourceInputText | AgentSessionMessageContent.MessageContentResourceInputImage | AgentSessionMessageContent.MessageContentResourceOutputText;
export declare namespace AgentSessionMessageContent {
    /**
     * Text supplied by the user.
     */
    interface MessageContentResourceInputText {
        /**
         * The text supplied by the user.
         */
        text: string;
        /**
         * The type of the object. Always `input_text`.
         */
        type: 'input_text';
    }
    /**
     * An image supplied by the user.
     */
    interface MessageContentResourceInputImage {
        /**
         * The URL of the image supplied by the user, which may be a base64-encoded data
         * URL.
         */
        image_url: string;
        /**
         * The type of the object. Always `input_image`.
         */
        type: 'input_image';
    }
    /**
     * Text produced by the assistant.
     */
    interface MessageContentResourceOutputText {
        /**
         * The text produced by the assistant.
         */
        text: string;
        /**
         * The type of the object. Always `output_text`.
         */
        type: 'output_text';
    }
}
/**
 * Emitted when a session is waiting for one or more required actions.
 */
export interface AgentSessionRequiresActionEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The session and its current required actions.
     */
    session: AgentSession;
    /**
     * The type of the object. Always `agent.session.requires_action`.
     */
    type: 'agent.session.requires_action';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a closed subagent successfully resumes.
 */
export interface AgentSessionSubagentActiveEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The subagent that resumed.
     */
    subagent: Subagent;
    /**
     * The type of the object. Always `agent.session.subagent.active`.
     */
    type: 'agent.session.subagent.active';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a subagent is closed.
 */
export interface AgentSessionSubagentClosedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The subagent that was closed.
     */
    subagent: Subagent;
    /**
     * The type of the object. Always `agent.session.subagent.closed`.
     */
    type: 'agent.session.subagent.closed';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a subagent is created.
 */
export interface AgentSessionSubagentCreatedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The subagent that was created.
     */
    subagent: Subagent;
    /**
     * The type of the object. Always `agent.session.subagent.created`.
     */
    type: 'agent.session.subagent.created';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a turn is cancelled.
 */
export interface AgentSessionTurnCancelledEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The cancelled turn.
     */
    turn: TurnsAPI.Turn;
    /**
     * The ID of the turn associated with the event.
     */
    turn_id: string;
    /**
     * The type of the object. Always `agent.session.turn.cancelled`.
     */
    type: 'agent.session.turn.cancelled';
    /**
     * Token usage by the root agent during the turn, when available.
     */
    usage: TokenUsage | null;
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a turn completes.
 */
export interface AgentSessionTurnCompletedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The completed turn.
     */
    turn: TurnsAPI.Turn;
    /**
     * The ID of the turn associated with the event.
     */
    turn_id: string;
    /**
     * The type of the object. Always `agent.session.turn.completed`.
     */
    type: 'agent.session.turn.completed';
    /**
     * Token usage by the root agent during the turn, when available.
     */
    usage: TokenUsage | null;
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when an output text content part is added.
 */
export interface AgentSessionTurnContentPartAddedEvent {
    /**
     * The index of the content part in the message.
     */
    content_index: number;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the message item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The initial content part.
     */
    part: OutputText;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.turn.content_part.added`.
     */
    type: 'agent.session.turn.content_part.added';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when an output content part is complete.
 */
export interface AgentSessionTurnContentPartDoneEvent {
    /**
     * The index of the content part in the message.
     */
    content_index: number;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the message item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The completed content part.
     */
    part: OutputText;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.turn.content_part.done`.
     */
    type: 'agent.session.turn.content_part.done';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a turn is created.
 */
export interface AgentSessionTurnCreatedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The turn at the time it was created.
     */
    turn: TurnsAPI.Turn;
    /**
     * The ID of the turn associated with the event.
     */
    turn_id: string;
    /**
     * The type of the object. Always `agent.session.turn.created`.
     */
    type: 'agent.session.turn.created';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a turn fails.
 */
export interface AgentSessionTurnFailedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The failed turn.
     */
    turn: TurnsAPI.Turn;
    /**
     * The ID of the turn associated with the event.
     */
    turn_id: string;
    /**
     * The type of the object. Always `agent.session.turn.failed`.
     */
    type: 'agent.session.turn.failed';
    /**
     * Token usage by the root agent during the turn, when available.
     */
    usage: TokenUsage | null;
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a turn starts running.
 */
export interface AgentSessionTurnInProgressEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The turn at the time it started running.
     */
    turn: TurnsAPI.Turn;
    /**
     * The ID of the turn associated with the event.
     */
    turn_id: string;
    /**
     * The type of the object. Always `agent.session.turn.in_progress`.
     */
    type: 'agent.session.turn.in_progress';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when an item is added to a turn.
 */
export interface AgentSessionTurnItemAddedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The item that was added.
     */
    item: AgentSessionItem;
    /**
     * The index of the item in the turn output, when the item is agent output.
     */
    output_index: number | null;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.turn.item.added`.
     */
    type: 'agent.session.turn.item.added';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when an output item is complete.
 */
export interface AgentSessionTurnItemDoneEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The completed output item.
     */
    item: AgentOutputItem;
    /**
     * The index of the output item in the turn output.
     */
    output_index: number;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.turn.item.done`.
     */
    type: 'agent.session.turn.item.done';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when text is appended to an output text content part.
 */
export interface AgentSessionTurnOutputTextDeltaEvent {
    /**
     * The index of the content part in the message.
     */
    content_index: number;
    /**
     * The text that was appended.
     */
    delta: string;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the message item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.turn.output_text.delta`.
     */
    type: 'agent.session.turn.output_text.delta';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when an output text content part is complete.
 */
export interface AgentSessionTurnOutputTextDoneEvent {
    /**
     * The index of the content part in the message.
     */
    content_index: number;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the message item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The complete output text.
     */
    text: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.turn.output_text.done`.
     */
    type: 'agent.session.turn.output_text.done';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a reasoning summary content part is added.
 */
export interface AgentSessionTurnReasoningSummaryPartAddedEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the reasoning item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The initial summary part.
     */
    part: SummaryText;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The index of the summary content part.
     */
    summary_index: number;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always
     * `agent.session.turn.reasoning_summary_part.added`.
     */
    type: 'agent.session.turn.reasoning_summary_part.added';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a reasoning summary part is complete.
 */
export interface AgentSessionTurnReasoningSummaryPartDoneEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the reasoning item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The completed summary part.
     */
    part: SummaryText;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * Present as `incomplete` when summary generation was interrupted.
     */
    status: 'incomplete' | null;
    /**
     * The index of the summary part.
     */
    summary_index: number;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.turn.reasoning_summary_part.done`.
     */
    type: 'agent.session.turn.reasoning_summary_part.done';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when text is appended to a reasoning summary.
 */
export interface AgentSessionTurnReasoningSummaryTextDeltaEvent {
    /**
     * The summary text that was appended.
     */
    delta: string;
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the reasoning item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The index of the summary content part.
     */
    summary_index: number;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always
     * `agent.session.turn.reasoning_summary_text.delta`.
     */
    type: 'agent.session.turn.reasoning_summary_text.delta';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * Emitted when a reasoning summary content part is complete.
 */
export interface AgentSessionTurnReasoningSummaryTextDoneEvent {
    /**
     * The unique ID of the event.
     */
    event_id: string;
    /**
     * The ID of the reasoning item.
     */
    item_id: string;
    /**
     * The index of the item in the turn output.
     */
    output_index: number;
    /**
     * The ID of the session associated with the event.
     */
    session_id: string;
    /**
     * The index of the summary content part.
     */
    summary_index: number;
    /**
     * The complete reasoning summary text.
     */
    text: string;
    /**
     * The ID of the turn associated with the event, when applicable.
     */
    turn_id: string | null;
    /**
     * The type of the object. Always `agent.session.turn.reasoning_summary_text.done`.
     */
    type: 'agent.session.turn.reasoning_summary_text.done';
    /**
     * Random alphanumeric padding. Present when stream obfuscation is enabled.
     */
    obfuscation?: string;
}
/**
 * The text configuration used by an agent.
 */
export interface AgentText {
    /**
     * The effective output format. Defaults to ordinary text.
     */
    format: TextFormat;
    /**
     * The amount of text produced by the agent. Defaults to `medium`.
     */
    verbosity: 'low' | 'medium' | 'high';
}
/**
 * Configuration for text generated by the agent.
 */
export interface AgentTextParam {
    /**
     * The output format. Omission uses ordinary text (`{"type": "text"}`).
     */
    format?: TextFormatParam | null;
    /**
     * The amount of text the model should produce. Defaults to `medium`, matching
     * Responses.
     *
     * - `low` - Produces less text.
     * - `medium` - Uses the default amount of text.
     * - `high` - Produces more text.
     */
    verbosity?: 'low' | 'medium' | 'high' | null;
}
/**
 * A tool available to the agent.
 */
export type AgentTool = AgentTool.AgentToolResourceFunction | AgentTool.AgentToolResourceProgrammaticToolCalling | AgentTool.AgentToolResourceMcp | AgentTool.AgentToolResourceWebSearch | AgentTool.AgentToolResourceComputerUse | AgentTool.AgentToolResourceAutomations;
export declare namespace AgentTool {
    /**
     * A function defined by the application.
     */
    interface AgentToolResourceFunction {
        /**
         * Whether the function is deferred and discovered through tool search.
         */
        defer_loading: boolean;
        /**
         * A description of what the function does.
         */
        description: string;
        /**
         * The name of the function.
         */
        name: string;
        /**
         * A JSON Schema object describing the function's arguments.
         */
        parameters: {
            [key: string]: unknown;
        };
        /**
         * The type of the object. Always `function`.
         */
        type: 'function';
        /**
         * Whether the agent continues without waiting for the function result.
         */
        async?: boolean;
    }
    /**
     * Enables calling tools from model-generated code.
     */
    interface AgentToolResourceProgrammaticToolCalling {
        /**
         * Whether tools can be called from model-generated code.
         */
        enabled: boolean;
        /**
         * The type of the object. Always `programmatic_tool_calling`.
         */
        type: 'programmatic_tool_calling';
    }
    /**
     * Tools provided by a remote MCP server.
     */
    interface AgentToolResourceMcp {
        /**
         * The MCP tools the agent may call.
         */
        allowed_tools: Array<string> | null;
        /**
         * Where outbound MCP HTTP connections originate.
         */
        connection_origin: 'service' | 'environment';
        /**
         * The attached vault credential selected for this MCP server, if any. Optional
         * when exactly one attached credential matches the server URL.
         */
        credential_id: string | null;
        /**
         * Metadata included with requests to this MCP server.
         */
        request_metadata: {
            [key: string]: unknown;
        };
        /**
         * Whether this MCP server must initialize before the first turn.
         */
        required: boolean;
        /**
         * A label used to identify the MCP server in tool calls.
         */
        server_label: string;
        /**
         * The transport used to connect to the MCP server.
         */
        transport: AgentsAPI.McpTransport;
        /**
         * The type of the object. Always `mcp`.
         */
        type: 'mcp';
    }
    /**
     * Web search.
     */
    interface AgentToolResourceWebSearch {
        /**
         * Allowed search domains, or `null` when the search is unrestricted.
         */
        allowed_domains: Array<string> | null;
        /**
         * The amount of search context made available to the model. Defaults to `medium`.
         */
        context_size: 'low' | 'medium' | 'high';
        /**
         * Approximate location used to localize search results, if provided.
         */
        location: AgentToolResourceWebSearch.Location | null;
        /**
         * The source used for web search results.
         */
        mode: 'disabled' | 'cached' | 'live';
        /**
         * The type of the object. Always `web_search`.
         */
        type: 'web_search';
    }
    namespace AgentToolResourceWebSearch {
        /**
         * Approximate location used to localize search results, if provided.
         */
        interface Location {
            /**
             * The city name.
             */
            city: string | null;
            /**
             * The two-letter ISO country code, such as `US`.
             */
            country: string | null;
            /**
             * The region or state name.
             */
            region: string | null;
            /**
             * The IANA timezone, such as `America/Los_Angeles`.
             */
            timezone: string | null;
        }
    }
    /**
     * Browser use in an OpenAI-hosted session.
     */
    interface AgentToolResourceComputerUse {
        /**
         * Whether computer tool outputs include screenshots.
         */
        include_screenshots: boolean;
        /**
         * The type of the object. Always `computer_use`.
         */
        type: 'computer_use';
    }
    /**
     * Lets the agent manage its own scheduled wakeups.
     */
    interface AgentToolResourceAutomations {
        /**
         * The type of the object. Always `automations`.
         */
        type: 'automations';
    }
}
/**
 * A tool available to the agent.
 */
export type AgentToolParam = AgentToolParam.AgentToolConfigParamFunction | AgentToolParam.AgentToolConfigParamToolSearch | AgentToolParam.AgentToolConfigParamProgrammaticToolCalling | AgentToolParam.AgentToolConfigParamMcp | AgentToolParam.AgentToolConfigParamWebSearch | AgentToolParam.AgentToolConfigParamComputerUse | AgentToolParam.AgentToolConfigParamAutomations;
export declare namespace AgentToolParam {
    /**
     * A function defined by the application.
     */
    interface AgentToolConfigParamFunction {
        /**
         * A description of what the function does.
         */
        description: string;
        /**
         * The name of the function.
         */
        name: string;
        /**
         * A JSON Schema object describing the function's arguments.
         */
        parameters: {
            [key: string]: unknown;
        };
        /**
         * The type of the object. Always `function`.
         */
        type: 'function';
        /**
         * Whether the agent continues without waiting for the function result. Defaults to
         * `false`.
         */
        async?: boolean;
        /**
         * Whether this function is deferred and discovered through tool search. Defaults
         * to `false`.
         */
        defer_loading?: boolean;
    }
    /**
     * Discovers deferred function tools and loads them into the model context.
     */
    interface AgentToolConfigParamToolSearch {
        /**
         * The type of the object. Always `tool_search`.
         */
        type: 'tool_search';
    }
    /**
     * Enables calling tools from model-generated code.
     */
    interface AgentToolConfigParamProgrammaticToolCalling {
        /**
         * The type of the object. Always `programmatic_tool_calling`.
         */
        type: 'programmatic_tool_calling';
        /**
         * Whether tools can be called from model-generated code. Defaults to `true`.
         */
        enabled?: boolean;
    }
    /**
     * Tools provided by a remote MCP server.
     */
    interface AgentToolConfigParamMcp {
        /**
         * A label used to identify the MCP server in tool calls.
         */
        server_label: string;
        /**
         * The transport used to connect to the MCP server.
         */
        transport: AgentsAPI.McpTransportParam;
        /**
         * The type of the object. Always `mcp`.
         */
        type: 'mcp';
        /**
         * The MCP tools the agent may call. All server tools are allowed when omitted.
         */
        allowed_tools?: Array<string> | null;
        /**
         * Selects where outbound MCP HTTP connections originate. Omitted or `service` uses
         * the Managed Agents service network; `environment` uses the session's selected
         * environment.
         *
         * - `service` - Uses the Managed Agents service network.
         * - `environment` - Uses the session's execution environment.
         */
        connection_origin?: 'service' | 'environment' | null;
        /**
         * The attached vault credential used to authenticate this MCP server. Optional
         * when exactly one attached credential matches the server URL.
         */
        credential_id?: string | null;
        /**
         * Metadata included with requests to this MCP server.
         */
        request_metadata?: {
            [key: string]: unknown;
        } | null;
        /**
         * Whether this MCP server must initialize before the first turn. Defaults to
         * `false`.
         */
        required?: boolean;
    }
    /**
     * Web search.
     */
    interface AgentToolConfigParamWebSearch {
        /**
         * The type of the object. Always `web_search`.
         */
        type: 'web_search';
        /**
         * Domains the search may include.
         */
        allowed_domains?: Array<string> | null;
        /**
         * The amount of search context made available to the model. Defaults to `medium`.
         */
        context_size?: 'low' | 'medium' | 'high' | null;
        /**
         * Approximate location used to localize search results.
         */
        location?: AgentToolConfigParamWebSearch.Location | null;
        /**
         * The source used for web search results. Defaults to `live`.
         *
         * - `disabled` - Disables web search.
         * - `cached` - Uses cached search results.
         * - `live` - Searches the live web.
         */
        mode?: 'disabled' | 'cached' | 'live' | null;
    }
    namespace AgentToolConfigParamWebSearch {
        /**
         * Approximate location used to localize search results.
         */
        interface Location {
            /**
             * The city name.
             */
            city?: string | null;
            /**
             * The two-letter ISO country code, such as `US`.
             */
            country?: string | null;
            /**
             * The region or state name.
             */
            region?: string | null;
            /**
             * The IANA timezone, such as `America/Los_Angeles`.
             */
            timezone?: string | null;
        }
    }
    /**
     * Browser use in an OpenAI-hosted session.
     */
    interface AgentToolConfigParamComputerUse {
        /**
         * The type of the object. Always `computer_use`.
         */
        type: 'computer_use';
        /**
         * Whether computer tool outputs include screenshots. Defaults to `false`.
         */
        include_screenshots?: boolean;
    }
    /**
     * Lets the agent manage its own scheduled wakeups.
     */
    interface AgentToolConfigParamAutomations {
        /**
         * The type of the object. Always `automations`.
         */
        type: 'automations';
    }
}
/**
 * A request to wait for one or more subagents.
 */
export interface AgentWaitForSubagentsCallItem {
    /**
     * The ID of the tool call item.
     */
    id: string;
    /**
     * The IDs of the agents to wait for.
     */
    recipient_agent_ids: Array<string>;
    /**
     * The ID of the agent waiting for results.
     */
    sender_agent_id: string;
    /**
     * The status of the tool call.
     */
    status: AgentFunctionCallStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `wait_for_subagents_call`.
     */
    type: 'wait_for_subagents_call';
}
/**
 * A web search call produced by the agent.
 */
export interface AgentWebSearchCallItem {
    /**
     * The ID of the web search call.
     */
    id: string;
    /**
     * The action performed by the web search tool.
     */
    action: WebSearchAction | null;
    /**
     * The status of the web search call.
     */
    status: AgentOutputItemStatus;
    /**
     * The ID of the turn that contains this item.
     */
    turn_id: string;
    /**
     * The item type. Always `web_search_call`.
     */
    type: 'web_search_call';
}
/**
 * The execution environment for a session.
 */
export type Environment = Environment.EnvironmentResourceNone | Environment.EnvironmentResourceOpenAIHosted | Environment.EnvironmentResourceSelfHosted;
export declare namespace Environment {
    /**
     * The session talks to CCA without selecting or provisioning an execution
     * environment.
     */
    interface EnvironmentResourceNone {
        /**
         * The type of the object. Always `none`.
         */
        type: 'none';
    }
    /**
     * An environment hosted by OpenAI.
     */
    interface EnvironmentResourceOpenAIHosted {
        /**
         * The public ID of the environment.
         */
        id: string;
        /**
         * Directories that contain capabilities exposed to the agent.
         */
        capability_directories: Array<string>;
        /**
         * Files available in the environment, excluding their contents.
         */
        files: Array<AgentsAPI.HostedEnvironmentFile>;
        /**
         * The effective network access policy for the environment.
         */
        network: EnvironmentResourceOpenAIHosted.Network;
        /**
         * Packages installed in the environment.
         */
        packages: EnvironmentResourceOpenAIHosted.Packages;
        /**
         * Plugins installed in the environment, excluding their archive contents.
         */
        plugins: Array<AgentsAPI.HostedPlugin>;
        /**
         * Skills installed in the environment, excluding their archive contents.
         */
        skills: Array<AgentsAPI.HostedSkill>;
        /**
         * The type of the object. Always `openai_hosted`.
         */
        type: 'openai_hosted';
        /**
         * The effective CPU and memory tier, or null when unknown or outside the public
         * tiers.
         */
        container_size?: 'small' | 'medium' | 'large' | null;
        /**
         * The effective desktop configuration.
         */
        desktop?: EnvironmentResourceOpenAIHosted.Desktop;
    }
    namespace EnvironmentResourceOpenAIHosted {
        /**
         * The effective network access policy for the environment.
         */
        interface Network {
            /**
             * The environment's network access mode.
             *
             * - `enabled` - Allows unrestricted network access.
             * - `disabled` - Disables network access.
             * - `restricted` - Applies the configured domain restrictions.
             */
            access: 'enabled' | 'disabled' | 'restricted';
            /**
             * Domains the environment may access when network access is restricted.
             */
            allowed_domains: Array<string>;
        }
        /**
         * Packages installed in the environment.
         */
        interface Packages {
            /**
             * npm packages installed globally in the environment.
             */
            npm: Array<string>;
            /**
             * Python packages installed in the environment.
             */
            python: Array<string>;
            /**
             * System packages installed in the environment.
             */
            system: Array<string>;
        }
        /**
         * The effective desktop configuration.
         */
        interface Desktop {
            /**
             * Whether the environment provisions a desktop and browser proxy.
             */
            enabled: boolean;
        }
    }
    /**
     * An environment hosted by the application.
     */
    interface EnvironmentResourceSelfHosted {
        /**
         * The public ID of the environment.
         */
        id: string;
        /**
         * Directories that contain capabilities exposed to the agent.
         */
        capability_directories: Array<string>;
        /**
         * Pass this URL unchanged to `codex exec-server --remote` when connecting this
         * environment.
         */
        remote_url: string;
        /**
         * The type of the object. Always `self_hosted`.
         */
        type: 'self_hosted';
        /**
         * The absolute project directory inside the environment. Defaults to `/workspace`.
         */
        workspace_directory: string;
    }
}
/**
 * The execution environment and optional reusable template for a session.
 */
export type EnvironmentParam = EnvironmentParam.EnvironmentParamNone | EnvironmentParam.EnvironmentParamOpenAIHosted | EnvironmentParam.EnvironmentParamSelfHosted | EnvironmentParam.EnvironmentParamPrewarmed;
export declare namespace EnvironmentParam {
    /**
     * Runs the agent without an execution environment.
     */
    interface EnvironmentParamNone {
        /**
         * The type of the object. Always `none`.
         */
        type: 'none';
    }
    /**
     * An existing OpenAI-hosted environment or new inline/template-based hosted
     * configuration.
     */
    interface EnvironmentParamOpenAIHosted {
        /**
         * The type of the object. Always `openai_hosted`.
         */
        type: 'openai_hosted';
        /**
         * Directories that contain capabilities exposed to the agent. Defaults to an empty
         * list.
         */
        capability_directories?: Array<string> | null;
        /**
         * The hosted container size. Omission selects the medium tier.
         */
        container_size?: 'small' | 'medium' | 'large';
        /**
         * Desktop provisioning. Omission or null inherits the template setting, or
         * defaults to disabled.
         */
        desktop?: EnvironmentParamOpenAIHosted.Desktop | null;
        /**
         * Environment variables made available to the agent.
         */
        env?: {
            [key: string]: string;
        } | null;
        /**
         * Use EnvironmentParamPrewarmed to attach an existing environment instead.
         */
        environment_id?: never;
        /**
         * A reusable hosted template applied before inline session configuration. Omitted
         * fields inherit the template; network overrides cannot broaden its policy.
         */
        environment_template_id?: string;
        /**
         * Files available before the agent starts. Defaults to an empty list.
         */
        files?: Array<AgentsAPI.HostedEnvironmentFileParam> | null;
        /**
         * Network access policy for the environment. If omitted, the API version
         * determines whether network access is enabled or disabled.
         */
        network?: EnvironmentParamOpenAIHosted.Network | null;
        /**
         * Packages to install in the environment. Defaults to empty package lists.
         */
        packages?: EnvironmentParamOpenAIHosted.Packages | null;
        /**
         * Plugins provided as inline ZIP archives. Defaults to an empty list.
         */
        plugins?: Array<AgentsAPI.HostedPluginParam> | null;
        /**
         * Ordered, confidential setup commands. Command bodies are never returned.
         */
        setup_commands?: Array<AgentsAPI.SetupCommandParam> | null;
        /**
         * Skills referenced by ID or provided as inline ZIP archives. Defaults to an empty
         * list.
         */
        skills?: Array<AgentsAPI.HostedSkillParam> | null;
    }
    namespace EnvironmentParamOpenAIHosted {
        /**
         * Desktop provisioning. Omission or null inherits the template setting, or
         * defaults to disabled.
         */
        interface Desktop {
            /**
             * Whether to provision the desktop and its browser proxy.
             */
            enabled: boolean;
        }
        /**
         * Network access policy for the environment. If omitted, the API version
         * determines whether network access is enabled or disabled.
         */
        interface Network {
            /**
             * The environment's network access mode.
             *
             * - `enabled` - Allows unrestricted network access.
             * - `disabled` - Disables network access.
             * - `restricted` - Applies the configured domain restrictions.
             */
            access: 'enabled' | 'disabled' | 'restricted';
            /**
             * Domains the environment may access when network access is restricted.
             */
            allowed_domains?: Array<string> | null;
            /**
             * Domains blocked for both executor and browser when access is restricted. A
             * nonempty list requires `access: restricted` and cannot be combined with nonempty
             * `allowed_domains`. Wildcard domains are not supported.
             */
            blocked_domains?: Array<string> | null;
        }
        /**
         * Packages to install in the environment. Defaults to empty package lists.
         */
        interface Packages {
            /**
             * npm packages to install globally. Defaults to an empty list.
             */
            npm?: Array<string> | null;
            /**
             * Python packages to install. Defaults to an empty list.
             */
            python?: Array<string> | null;
            /**
             * System packages to install. Defaults to an empty list.
             */
            system?: Array<string> | null;
        }
    }
    /**
     * An application-hosted environment configured inline.
     */
    interface EnvironmentParamSelfHosted {
        /**
         * The type of the object. Always `self_hosted`.
         */
        type: 'self_hosted';
        /**
         * Absolute project directory inside the self-hosted environment.
         */
        workspace_directory: string;
        /**
         * Directories that contain capabilities exposed to the agent. Defaults to an empty
         * list.
         */
        capability_directories?: Array<string> | null;
    }
}
/**
 * Metadata for a file materialized in an OpenAI-hosted execution environment.
 */
export type HostedEnvironmentFile = HostedEnvironmentFileID | HostedEnvironmentFile.HostedEnvironmentFileResourceInline;
export declare namespace HostedEnvironmentFile {
    /**
     * A file supplied inline when the session was created.
     */
    interface HostedEnvironmentFileResourceInline {
        /**
         * The session-scoped ID of the file in the execution environment.
         */
        id: string;
        /**
         * The file's absolute path inside the environment.
         */
        path: string;
        /**
         * The decoded file size in bytes.
         */
        size_bytes: number;
        /**
         * The type of the object. Always `inline`.
         */
        type: 'inline';
    }
}
/**
 * A file copied from the OpenAI Files API.
 */
export interface HostedEnvironmentFileID {
    /**
     * The session-scoped ID of the file in the execution environment.
     */
    id: string;
    /**
     * The ID of the uploaded file.
     */
    file_id: string;
    /**
     * The file's absolute path inside the environment.
     */
    path: string;
    /**
     * The decoded file size in bytes.
     */
    size_bytes: number;
    /**
     * The type of the object. Always `file_id`.
     */
    type: 'file_id';
}
/**
 * A file materialized in an OpenAI-hosted execution environment.
 */
export type HostedEnvironmentFileParam = HostedEnvironmentFileParam.HostedEnvironmentFileParamFileID | HostedEnvironmentFileParam.HostedEnvironmentFileParamInline;
export declare namespace HostedEnvironmentFileParam {
    /**
     * A file previously uploaded through the OpenAI Files API.
     */
    interface HostedEnvironmentFileParamFileID {
        /**
         * The ID of the uploaded file.
         */
        file_id: string;
        /**
         * The absolute destination path inside `/workspace`.
         */
        path: string;
        /**
         * The type of the object. Always `file_id`.
         */
        type: 'file_id';
    }
    /**
     * A file supplied directly as standard-base64 data.
     */
    interface HostedEnvironmentFileParamInline {
        /**
         * The standard-base64-encoded file contents.
         */
        data: string;
        /**
         * The absolute destination path inside `/workspace`.
         */
        path: string;
        /**
         * The type of the object. Always `inline`.
         */
        type: 'inline';
    }
}
/**
 * A plugin installed from an inline ZIP archive.
 */
export interface HostedPlugin {
    /**
     * The installed plugin description.
     */
    description: string;
    /**
     * The installed plugin name.
     */
    name: string;
    /**
     * The type of the object. Always `inline`.
     */
    type: 'inline';
}
/**
 * Supplies a plugin ZIP directly in the session request.
 */
export interface HostedPluginParam {
    /**
     * The plugin description declared in `.codex-plugin/plugin.json`.
     */
    description: string;
    /**
     * The plugin name declared in `.codex-plugin/plugin.json`.
     */
    name: string;
    /**
     * Provides ZIP bytes encoded with standard base64.
     */
    source: InlineCapabilitySourceParam;
    /**
     * The type of the object. Always `inline`.
     */
    type: 'inline';
}
/**
 * A skill installed in an OpenAI-hosted environment.
 */
export type HostedSkill = HostedSkillReference | HostedSkill.HostedSkillResourceInline;
export declare namespace HostedSkill {
    /**
     * A skill installed from an inline ZIP archive.
     */
    interface HostedSkillResourceInline {
        /**
         * The installed skill description.
         */
        description: string;
        /**
         * The installed skill name.
         */
        name: string;
        /**
         * The type of the object. Always `inline`.
         */
        type: 'inline';
    }
}
/**
 * A skill installed in an OpenAI-hosted environment.
 */
export type HostedSkillParam = HostedSkillParam.HostedSkillParamSkillReference | HostedSkillParam.HostedSkillParamInline;
export declare namespace HostedSkillParam {
    /**
     * References a skill uploaded through the Skills API.
     */
    interface HostedSkillParamSkillReference {
        /**
         * The ID of the skill created through `/v1/skills`.
         */
        skill_id: string;
        /**
         * The type of the object. Always `skill_reference`.
         */
        type: 'skill_reference';
        /**
         * The skill version, a positive integer or `latest`; omission selects the default.
         */
        version?: string | null;
    }
    /**
     * Supplies a skill ZIP directly in the session request.
     */
    interface HostedSkillParamInline {
        /**
         * The skill description declared in `SKILL.md`.
         */
        description: string;
        /**
         * The skill name declared in `SKILL.md`.
         */
        name: string;
        /**
         * Provides ZIP bytes encoded with standard base64.
         */
        source: AgentsAPI.InlineCapabilitySourceParam;
        /**
         * The type of the object. Always `inline`.
         */
        type: 'inline';
    }
}
/**
 * A skill installed from the Skills API.
 */
export interface HostedSkillReference {
    /**
     * The installed skill description.
     */
    description: string;
    /**
     * The installed skill name.
     */
    name: string;
    /**
     * The referenced skill ID.
     */
    skill_id: string;
    /**
     * The type of the object. Always `skill_reference`.
     */
    type: 'skill_reference';
    /**
     * The concrete skill version installed for this session.
     */
    version: string;
}
/**
 * Provides ZIP bytes encoded with standard base64.
 */
export interface InlineCapabilitySourceParam {
    /**
     * Standard-base64 encoded ZIP archive bytes.
     */
    data: string;
    /**
     * The archive media type, always `application/zip`.
     */
    media_type: 'application/zip';
    /**
     * The type of the object. Always `base64`.
     */
    type: 'base64';
}
/**
 * User-provided content recorded in a session item.
 */
export type InputContent = InputContent.InputContentResourceInputText | InputContent.InputContentResourceInputImage;
export declare namespace InputContent {
    /**
     * Text input recorded in a session item.
     */
    interface InputContentResourceInputText {
        /**
         * The text supplied to the agent.
         */
        text: string;
        /**
         * The type of the object. Always `input_text`.
         */
        type: 'input_text';
    }
    /**
     * Image input recorded in a session item.
     */
    interface InputContentResourceInputImage {
        /**
         * The URL of the image supplied to the agent, which may be a base64-encoded data
         * URL.
         */
        image_url: string;
        /**
         * The type of the object. Always `input_image`.
         */
        type: 'input_image';
    }
}
/**
 * Content included in an input message.
 */
export type InputContentParam = InputContentParam.InputContentParamInputText | InputContentParam.InputContentParamInputImage;
export declare namespace InputContentParam {
    /**
     * Text input to the model.
     */
    interface InputContentParamInputText {
        /**
         * The text sent to the model.
         */
        text: string;
        /**
         * The type of the object. Always `input_text`.
         */
        type: 'input_text';
    }
    /**
     * Image input to the model.
     */
    interface InputContentParamInputImage {
        /**
         * The URL of the image sent to the model.
         */
        image_url: string;
        /**
         * The type of the object. Always `input_image`.
         */
        type: 'input_image';
    }
}
/**
 * The transport used to connect to an MCP server.
 */
export type McpTransport = McpTransport.McpTransportResourceHTTP | McpTransport.McpTransportResourceStdio;
export declare namespace McpTransport {
    /**
     * Connects to an MCP server over HTTP.
     */
    interface McpTransportResourceHTTP {
        /**
         * The URL of the MCP server.
         */
        server_url: string;
        /**
         * The type of the object. Always `http`.
         */
        type: 'http';
    }
    /**
     * Starts an MCP server as a local process.
     */
    interface McpTransportResourceStdio {
        /**
         * Arguments passed to the MCP server command.
         */
        args: Array<string>;
        /**
         * The command used to start the MCP server.
         */
        command: string;
        /**
         * The working directory used to start the MCP server.
         */
        cwd: string;
        /**
         * Environment variable names inherited from the execution environment.
         */
        env_vars: Array<string>;
        /**
         * The type of the object. Always `stdio`.
         */
        type: 'stdio';
    }
}
/**
 * The transport used to connect to an MCP server.
 */
export type McpTransportParam = McpTransportParam.McpTransportConfigParamHTTP | McpTransportParam.McpTransportConfigParamStdio;
export declare namespace McpTransportParam {
    /**
     * Connects to an MCP server over HTTP.
     */
    interface McpTransportConfigParamHTTP {
        /**
         * The URL of the MCP server.
         */
        server_url: string;
        /**
         * The type of the object. Always `http`.
         */
        type: 'http';
        /**
         * The authorization value sent to the MCP server, if any.
         */
        authorization?: string | null;
        /**
         * Additional HTTP headers sent to the MCP server.
         */
        headers?: {
            [key: string]: string;
        } | null;
    }
    /**
     * Starts an MCP server as a local process.
     */
    interface McpTransportConfigParamStdio {
        /**
         * The command used to start the MCP server.
         */
        command: string;
        /**
         * The working directory used to start the MCP server.
         */
        cwd: string;
        /**
         * The type of the object. Always `stdio`.
         */
        type: 'stdio';
        /**
         * Arguments passed to the MCP server command.
         */
        args?: Array<string> | null;
        /**
         * Environment variables set for the MCP server process.
         */
        env?: {
            [key: string]: string;
        } | null;
        /**
         * Environment variable names to inherit from the selected execution environment.
         */
        env_vars?: Array<string> | null;
    }
}
/**
 * The resolved configuration for creating and coordinating subagents.
 */
export interface MultiAgentConfig {
    /**
     * Whether subagent tools are enabled. Defaults to false.
     */
    enabled: boolean;
    /**
     * Maximum number of subagents that may run concurrently, or null when disabled.
     * Defaults to 6 when enabled.
     */
    max_concurrent_subagents: number | null;
}
/**
 * Explicit configuration for creating and coordinating subagents.
 */
export interface MultiAgentConfigParam {
    /**
     * Whether subagent tools are enabled.
     */
    enabled: boolean;
    /**
     * Maximum number of subagents that may run concurrently. Defaults to 6.
     */
    max_concurrent_subagents?: number;
}
/**
 * A text content part produced by the agent.
 */
export interface OutputText {
    /**
     * The text produced by the agent.
     */
    text: string;
    /**
     * The content type. Always `output_text`.
     */
    type: 'output_text';
}
/**
 * A credential-free tool available to a reusable agent.
 */
export type PersistedAgentTool = PersistedAgentTool.PersistedAgentToolResourceFunction | PersistedAgentTool.PersistedAgentToolResourceToolSearch | PersistedAgentTool.PersistedAgentToolResourceProgrammaticToolCalling | PersistedAgentTool.PersistedAgentToolResourceMcp | PersistedAgentTool.PersistedAgentToolResourceWebSearch | PersistedAgentTool.PersistedAgentToolResourceComputerUse | PersistedAgentTool.PersistedAgentToolResourceAutomations;
export declare namespace PersistedAgentTool {
    /**
     * A function defined by the application.
     */
    interface PersistedAgentToolResourceFunction {
        /**
         * Whether the function is deferred and discovered through tool search.
         */
        defer_loading: boolean;
        /**
         * A description of what the function does.
         */
        description: string;
        /**
         * The name of the function.
         */
        name: string;
        /**
         * A JSON Schema object describing the function's arguments.
         */
        parameters: {
            [key: string]: unknown;
        };
        /**
         * The type of the object. Always `function`.
         */
        type: 'function';
        /**
         * Whether the agent continues without waiting for the function result.
         */
        async?: boolean;
    }
    /**
     * Discovers deferred function tools and loads them into the model context.
     */
    interface PersistedAgentToolResourceToolSearch {
        /**
         * The type of the object. Always `tool_search`.
         */
        type: 'tool_search';
    }
    /**
     * Enables calling tools from model-generated code.
     */
    interface PersistedAgentToolResourceProgrammaticToolCalling {
        /**
         * Whether tools can be called from model-generated code.
         */
        enabled: boolean;
        /**
         * The type of the object. Always `programmatic_tool_calling`.
         */
        type: 'programmatic_tool_calling';
    }
    /**
     * Tools provided by a remote MCP server without stored credentials.
     */
    interface PersistedAgentToolResourceMcp {
        /**
         * The MCP tools the agent may call, or null when all server tools are allowed.
         */
        allowed_tools: Array<string> | null;
        /**
         * Where outbound MCP HTTP connections originate.
         */
        connection_origin: 'service' | 'environment';
        /**
         * The vault credential selected for this MCP server, if any.
         */
        credential_id: string | null;
        /**
         * Metadata included with requests to this MCP server.
         */
        request_metadata: {
            [key: string]: unknown;
        };
        /**
         * Whether this MCP server must initialize before the first turn.
         */
        required: boolean;
        /**
         * A label used to identify the MCP server in tool calls.
         */
        server_label: string;
        /**
         * The credential-free transport used to connect to the MCP server.
         */
        transport: AgentsAPI.PersistedMcpTransport;
        /**
         * The type of the object. Always `mcp`.
         */
        type: 'mcp';
    }
    /**
     * Web search.
     */
    interface PersistedAgentToolResourceWebSearch {
        /**
         * Allowed search domains, or `null` when the search is unrestricted.
         */
        allowed_domains: Array<string> | null;
        /**
         * The amount of search context made available to the model. Defaults to `medium`.
         */
        context_size: 'low' | 'medium' | 'high';
        /**
         * Approximate location used to localize search results, if provided.
         */
        location: PersistedAgentToolResourceWebSearch.Location | null;
        /**
         * The source used for web search results.
         */
        mode: 'disabled' | 'cached' | 'live';
        /**
         * The type of the object. Always `web_search`.
         */
        type: 'web_search';
    }
    namespace PersistedAgentToolResourceWebSearch {
        /**
         * Approximate location used to localize search results, if provided.
         */
        interface Location {
            /**
             * The city name.
             */
            city: string | null;
            /**
             * The two-letter ISO country code, such as `US`.
             */
            country: string | null;
            /**
             * The region or state name.
             */
            region: string | null;
            /**
             * The IANA timezone, such as `America/Los_Angeles`.
             */
            timezone: string | null;
        }
    }
    /**
     * Browser use in an OpenAI-hosted session.
     */
    interface PersistedAgentToolResourceComputerUse {
        /**
         * Whether computer tool outputs include screenshots.
         */
        include_screenshots: boolean;
        /**
         * The type of the object. Always `computer_use`.
         */
        type: 'computer_use';
    }
    /**
     * Lets the agent manage its own scheduled wakeups.
     */
    interface PersistedAgentToolResourceAutomations {
        /**
         * The type of the object. Always `automations`.
         */
        type: 'automations';
    }
}
/**
 * A tool that can be stored on a reusable agent without session credentials.
 */
export type PersistedAgentToolParam = PersistedAgentToolParam.PersistedAgentToolConfigParamFunction | PersistedAgentToolParam.PersistedAgentToolConfigParamToolSearch | PersistedAgentToolParam.PersistedAgentToolConfigParamProgrammaticToolCalling | PersistedAgentToolParam.PersistedAgentToolConfigParamMcp | PersistedAgentToolParam.PersistedAgentToolConfigParamWebSearch | PersistedAgentToolParam.PersistedAgentToolConfigParamComputerUse | PersistedAgentToolParam.PersistedAgentToolConfigParamAutomations;
export declare namespace PersistedAgentToolParam {
    /**
     * A function defined by the application.
     */
    interface PersistedAgentToolConfigParamFunction {
        /**
         * A description of what the function does.
         */
        description: string;
        /**
         * The name of the function.
         */
        name: string;
        /**
         * A JSON Schema object describing the function's arguments.
         */
        parameters: {
            [key: string]: unknown;
        };
        /**
         * The type of the object. Always `function`.
         */
        type: 'function';
        /**
         * Whether the agent continues without waiting for the function result. Defaults to
         * `false`.
         */
        async?: boolean;
        /**
         * Whether this function is deferred and discovered through tool search. Defaults
         * to `false`.
         */
        defer_loading?: boolean;
    }
    /**
     * Discovers deferred function tools and loads them into the model context.
     */
    interface PersistedAgentToolConfigParamToolSearch {
        /**
         * The type of the object. Always `tool_search`.
         */
        type: 'tool_search';
    }
    /**
     * Enables calling tools from model-generated code.
     */
    interface PersistedAgentToolConfigParamProgrammaticToolCalling {
        /**
         * The type of the object. Always `programmatic_tool_calling`.
         */
        type: 'programmatic_tool_calling';
        /**
         * Whether tools can be called from model-generated code. Defaults to `true`.
         */
        enabled?: boolean;
    }
    /**
     * Tools provided by a remote MCP server without stored credentials.
     */
    interface PersistedAgentToolConfigParamMcp {
        /**
         * A label used to identify the MCP server in tool calls.
         */
        server_label: string;
        /**
         * The credential-free transport used to connect to the MCP server.
         */
        transport: AgentsAPI.PersistedMcpTransportParam;
        /**
         * The type of the object. Always `mcp`.
         */
        type: 'mcp';
        /**
         * The MCP tools the agent may call. All server tools are allowed when omitted.
         */
        allowed_tools?: Array<string> | null;
        /**
         * Selects where outbound MCP HTTP connections originate.
         *
         * - `service` - Uses the Managed Agents service network.
         * - `environment` - Uses the session's execution environment.
         */
        connection_origin?: 'service' | 'environment' | null;
        /**
         * The vault credential selected for this MCP server. Optional when exactly one
         * attached credential matches the server URL.
         */
        credential_id?: string | null;
        /**
         * Metadata included with requests to this MCP server.
         */
        request_metadata?: {
            [key: string]: unknown;
        } | null;
        /**
         * Whether this MCP server must initialize before the first turn. Defaults to
         * `false`.
         */
        required?: boolean;
    }
    /**
     * Web search.
     */
    interface PersistedAgentToolConfigParamWebSearch {
        /**
         * The type of the object. Always `web_search`.
         */
        type: 'web_search';
        /**
         * Domains the search may include.
         */
        allowed_domains?: Array<string> | null;
        /**
         * The amount of search context made available to the model. Defaults to `medium`.
         */
        context_size?: 'low' | 'medium' | 'high' | null;
        /**
         * Approximate location used to localize search results.
         */
        location?: PersistedAgentToolConfigParamWebSearch.Location | null;
        /**
         * The source used for web search results. Defaults to `live`.
         *
         * - `disabled` - Disables web search.
         * - `cached` - Uses cached search results.
         * - `live` - Searches the live web.
         */
        mode?: 'disabled' | 'cached' | 'live' | null;
    }
    namespace PersistedAgentToolConfigParamWebSearch {
        /**
         * Approximate location used to localize search results.
         */
        interface Location {
            /**
             * The city name.
             */
            city?: string | null;
            /**
             * The two-letter ISO country code, such as `US`.
             */
            country?: string | null;
            /**
             * The region or state name.
             */
            region?: string | null;
            /**
             * The IANA timezone, such as `America/Los_Angeles`.
             */
            timezone?: string | null;
        }
    }
    /**
     * Browser use in an OpenAI-hosted session.
     */
    interface PersistedAgentToolConfigParamComputerUse {
        /**
         * The type of the object. Always `computer_use`.
         */
        type: 'computer_use';
        /**
         * Whether computer tool outputs include screenshots. Defaults to `false`.
         */
        include_screenshots?: boolean;
    }
    /**
     * Lets the agent manage its own scheduled wakeups.
     */
    interface PersistedAgentToolConfigParamAutomations {
        /**
         * The type of the object. Always `automations`.
         */
        type: 'automations';
    }
}
/**
 * A credential-free transport used to connect to an MCP server.
 */
export type PersistedMcpTransport = PersistedMcpTransport.PersistedMcpTransportResourceHTTP | PersistedMcpTransport.PersistedMcpTransportResourceStdio;
export declare namespace PersistedMcpTransport {
    /**
     * Connects to an MCP server over HTTP.
     */
    interface PersistedMcpTransportResourceHTTP {
        /**
         * Non-secret HTTP headers sent to the MCP server.
         */
        headers: {
            [key: string]: string;
        };
        /**
         * The URL of the MCP server.
         */
        server_url: string;
        /**
         * The type of the object. Always `http`.
         */
        type: 'http';
    }
    /**
     * Starts an MCP server as a local process.
     */
    interface PersistedMcpTransportResourceStdio {
        /**
         * Arguments passed to the MCP server command.
         */
        args: Array<string>;
        /**
         * The command used to start the MCP server.
         */
        command: string;
        /**
         * The working directory used to start the MCP server.
         */
        cwd: string;
        /**
         * Environment variable names inherited from the execution environment.
         */
        env_vars: Array<string>;
        /**
         * The type of the object. Always `stdio`.
         */
        type: 'stdio';
    }
}
/**
 * A credential-free transport used to connect to an MCP server.
 */
export type PersistedMcpTransportParam = PersistedMcpTransportParam.PersistedMcpTransportConfigParamHTTP | PersistedMcpTransportParam.PersistedMcpTransportConfigParamStdio;
export declare namespace PersistedMcpTransportParam {
    /**
     * Connects to an MCP server over HTTP.
     */
    interface PersistedMcpTransportConfigParamHTTP {
        /**
         * The URL of the MCP server.
         */
        server_url: string;
        /**
         * The type of the object. Always `http`.
         */
        type: 'http';
        /**
         * Non-secret HTTP headers sent to the MCP server.
         */
        headers?: {
            [key: string]: string;
        } | null;
    }
    /**
     * Starts an MCP server as a local process.
     */
    interface PersistedMcpTransportConfigParamStdio {
        /**
         * The command used to start the MCP server.
         */
        command: string;
        /**
         * The working directory used to start the MCP server.
         */
        cwd: string;
        /**
         * The type of the object. Always `stdio`.
         */
        type: 'stdio';
        /**
         * Arguments passed to the MCP server command.
         */
        args?: Array<string> | null;
        /**
         * Environment variable names to inherit from the selected execution environment.
         */
        env_vars?: Array<string> | null;
    }
}
/**
 * An error payload with the same public fields as Responses API streaming errors.
 */
export interface SessionError {
    /**
     * The machine-readable error code, if any.
     */
    code: string | null;
    /**
     * A customer-safe explanation of the error.
     */
    message: string;
    /**
     * The request parameter associated with the error, if any.
     */
    param: string | null;
    /**
     * The error type.
     */
    type: string;
}
/**
 * A customer-safe error describing why a session request failed.
 */
export interface SessionTurnError {
    /**
     * A stable, machine-readable failure category.
     *
     * - `context_length_exceeded` - The request exceeds the model's context window.
     * - `max_output_tokens` - The model reached its output token limit before
     *   finishing the response.
     * - `session_budget_exceeded` - The session has reached its usage budget.
     * - `usage_limit_exceeded` - The organization has reached a usage, plan, or
     *   billing limit.
     * - `project_spend_limit_exceeded` - The project has reached its enforced spend
     *   limit.
     * - `organization_spend_limit_exceeded` - The organization has reached its
     *   enforced spend limit.
     * - `organization_usage_limit_exceeded` - The organization has reached its
     *   OpenAI-assigned usage limit.
     * - `billing_not_active` - Billing is not active for the account.
     * - `credit_balance_exhausted` - The organization has no API credits remaining.
     * - `rate_limit_exceeded` - The request exceeds the available rate limit.
     * - `flex_unavailable` - Flex processing is temporarily unavailable.
     * - `server_overloaded` - The model service is temporarily overloaded.
     * - `cyber_policy` - The request was rejected by a safety policy.
     * - `misalignment_policy_violation` - The request was blocked by the safety
     *   systems.
     * - `connection_failed` - The request could not connect to the model service.
     * - `server_error` - The model service encountered an unexpected error.
     * - `authentication_error` - The API credentials are invalid or lack the required
     *   access.
     * - `invalid_request` - The request contains invalid input or configuration.
     * - `resource_not_found` - The requested model or resource is unavailable.
     * - `sandbox_error` - The request could not complete in its execution environment.
     * - `executor_version_incompatible` - The executor must be upgraded before it can
     *   run this turn.
     * - `active_turn_not_steerable` - The session cannot accept additional input while
     *   a request is running.
     * - `request_timeout` - The request timed out before the model service responded.
     * - `internal_error` - An unexpected internal error prevented the session request
     *   from completing.
     */
    code: 'context_length_exceeded' | 'max_output_tokens' | 'session_budget_exceeded' | 'usage_limit_exceeded' | 'project_spend_limit_exceeded' | 'organization_spend_limit_exceeded' | 'organization_usage_limit_exceeded' | 'billing_not_active' | 'credit_balance_exhausted' | 'rate_limit_exceeded' | 'flex_unavailable' | 'server_overloaded' | 'cyber_policy' | 'misalignment_policy_violation' | 'connection_failed' | 'server_error' | 'authentication_error' | 'invalid_request' | 'resource_not_found' | 'sandbox_error' | 'executor_version_incompatible' | 'active_turn_not_steerable' | 'request_timeout' | 'internal_error';
    /**
     * A customer-safe explanation of the failure.
     */
    message: string;
}
/**
 * A confidential setup command executed before the hosted agent starts.
 */
export interface SetupCommandParam {
    /**
     * The shell command to execute.
     */
    command: string;
    /**
     * The absolute working directory. Defaults to `/workspace`.
     */
    cwd?: string | null;
}
/**
 * A subagent created within a session.
 */
export interface Subagent {
    /**
     * The ID of the subagent.
     */
    id: string;
    /**
     * The Unix timestamp, in seconds, when the subagent was closed. Null while active,
     * including after resume.
     */
    closed_at: number | null;
    /**
     * Initial task content, or null when unavailable. Text may contain placeholders
     * for images or audio when only a preview is available.
     */
    instructions: Array<AgentContent> | null;
    /**
     * The runner-assigned nickname, or null when unavailable.
     */
    name: string | null;
    /**
     * The object type. Always `agent.session.subagent`.
     */
    object: 'agent.session.subagent';
    /**
     * The Unix timestamp, in seconds, when the subagent was first opened. Resuming
     * does not change it.
     */
    opened_at: number;
    /**
     * The ID of the agent that created this subagent.
     */
    parent_agent_id: string;
    /**
     * The ID of the session that owns the subagent.
     */
    session_id: string;
    /**
     * The current status of the subagent.
     *
     * - `active` - The subagent remains available, including while idle between turns.
     * - `closed` - The subagent is closed.
     */
    status: 'active' | 'closed';
}
/**
 * A reasoning summary content part.
 */
export interface SummaryText {
    /**
     * The reasoning summary text.
     */
    text: string;
    /**
     * The content type. Always `summary_text`.
     */
    type: 'summary_text';
}
/**
 * The effective output format for generated text.
 */
export type TextFormat = TextFormat.TextFormatResourceText | TextFormat.TextFormatResourceJSONSchema;
export declare namespace TextFormat {
    /**
     * Generates ordinary text without a structured-output constraint.
     */
    interface TextFormatResourceText {
        /**
         * The type of the object. Always `text`.
         */
        type: 'text';
    }
    /**
     * Constrains generated text to a JSON Schema.
     */
    interface TextFormatResourceJSONSchema {
        /**
         * The JSON Schema that generated text must match.
         */
        schema: {
            [key: string]: unknown;
        };
        /**
         * The type of the object. Always `json_schema`.
         */
        type: 'json_schema';
    }
}
/**
 * The output format for generated text.
 */
export type TextFormatParam = TextFormatParam.TextFormatParamText | TextFormatParam.TextFormatParamJSONSchema;
export declare namespace TextFormatParam {
    /**
     * Generates ordinary text without a structured-output constraint.
     */
    interface TextFormatParamText {
        /**
         * The type of the object. Always `text`.
         */
        type: 'text';
    }
    /**
     * Constrains generated text to a JSON Schema.
     */
    interface TextFormatParamJSONSchema {
        /**
         * The JSON Schema that generated text must match.
         */
        schema: {
            [key: string]: unknown;
        };
        /**
         * The type of the object. Always `json_schema`.
         */
        type: 'json_schema';
    }
}
/**
 * Recorded token usage for a session or turn. Usage is best effort and may change.
 */
export interface TokenUsage {
    /**
     * The number of input tokens used by the agent.
     */
    input_tokens: number;
    /**
     * A breakdown of the agent's input token usage.
     */
    input_tokens_details: TokenUsage.InputTokensDetails;
    /**
     * The number of output tokens generated by the agent.
     */
    output_tokens: number;
    /**
     * A breakdown of the agent's output token usage.
     */
    output_tokens_details: TokenUsage.OutputTokensDetails;
    /**
     * The total number of input and output tokens used by the agent.
     */
    total_tokens: number;
}
export declare namespace TokenUsage {
    /**
     * A breakdown of the agent's input token usage.
     */
    interface InputTokensDetails {
        /**
         * The number of input tokens retrieved from the prompt cache.
         */
        cached_tokens: number;
    }
    /**
     * A breakdown of the agent's output token usage.
     */
    interface OutputTokensDetails {
        /**
         * The number of output tokens used for reasoning.
         */
        reasoning_tokens: number;
    }
}
/**
 * An action performed by the web search tool.
 */
export type WebSearchAction = WebSearchAction.WebSearchActionResourceSearch | WebSearchAction.WebSearchActionResourceOpenPage | WebSearchAction.WebSearchActionResourceFindInPage | WebSearchAction.WebSearchActionResourceOther;
export declare namespace WebSearchAction {
    /**
     * A search query or group of search queries.
     */
    interface WebSearchActionResourceSearch {
        /**
         * The search queries, when multiple queries were used.
         */
        queries: Array<string> | null;
        /**
         * The search query, when a single query was used.
         */
        query: string | null;
        /**
         * The type of the object. Always `search`.
         */
        type: 'search';
    }
    /**
     * Opens a web page.
     */
    interface WebSearchActionResourceOpenPage {
        /**
         * The type of the object. Always `open_page`.
         */
        type: 'open_page';
        /**
         * The URL of the page that was opened.
         */
        url: string | null;
    }
    /**
     * Finds text within a web page.
     */
    interface WebSearchActionResourceFindInPage {
        /**
         * The text pattern that was searched for.
         */
        pattern: string | null;
        /**
         * The type of the object. Always `find_in_page`.
         */
        type: 'find_in_page';
        /**
         * The URL of the page that was searched.
         */
        url: string | null;
    }
    /**
     * Another web search action.
     */
    interface WebSearchActionResourceOther {
        /**
         * The type of the object. Always `other`.
         */
        type: 'other';
    }
}
export interface AgentCreateParams {
    /**
     * The model to use for the agent. The requested model name is preserved.
     */
    model: string;
    /**
     * Context compaction settings. Omission or null uses blocking compaction.
     */
    compaction?: AgentCreateParams.Compaction | null;
    /**
     * Experimental agent settings. All experimental features default to disabled.
     */
    experimental?: AgentCreateParams.Experimental;
    /**
     * Additional instructions appended to the agent's default base instructions. Omit
     * or set to null to add no custom instructions.
     */
    instructions?: string | null;
    /**
     * Up to 16 string key-value pairs, with keys up to 64 and values up to 512
     * characters. Omission or null defaults to an empty map.
     */
    metadata?: {
        [key: string]: string;
    } | null;
    /**
     * Configuration for creating and coordinating subagents. Subagent tools are
     * disabled by default.
     */
    multi_agent?: MultiAgentConfigParam | null;
    /**
     * A human-readable name for the agent. Omission or null leaves the agent unnamed.
     */
    name?: string | null;
    /**
     * Configuration for model reasoning. Omission uses the model's default effort.
     */
    reasoning?: AgentReasoningParam | null;
    /**
     * The service tier used for model requests. Defaults to `auto`.
     *
     * - `auto` - Selects the service tier automatically.
     * - `default` - Uses the default service tier.
     * - `flex` - Uses the flex service tier.
     * - `priority` - Uses the priority service tier.
     * - `fast` - Uses the fast service tier.
     * - `ultrafast` - Uses the ultrafast service tier.
     */
    service_tier?: 'auto' | 'default' | 'flex' | 'priority' | 'fast' | 'ultrafast' | null;
    /**
     * Configuration for generated text. Defaults to the `text` format and medium
     * verbosity.
     */
    text?: AgentTextParam | null;
    /**
     * Tools available to the agent. Defaults to an empty list. The tool list must fit
     * within 3 MiB (3,145,728 bytes) of compact UTF-8 JSON.
     */
    tools?: Array<PersistedAgentToolParam> | null;
}
export declare namespace AgentCreateParams {
    /**
     * Context compaction settings. Omission or null uses blocking compaction.
     */
    interface Compaction {
        /**
         * Whether to compact context in the background. Omission or null defaults to
         * false. Set to true to enable background compaction. Background compaction may
         * increase token usage.
         */
        async?: boolean | null;
    }
    /**
     * Experimental agent settings. All experimental features default to disabled.
     */
    interface Experimental {
        /**
         * Whether to give the model periodic current-time reminders. Defaults to false.
         */
        time_awareness?: boolean;
    }
}
export interface AgentUpdateParams {
    /**
     * Context compaction settings. Omit to keep the current settings. A supplied
     * object replaces the settings; null or an empty object uses blocking compaction.
     */
    compaction?: AgentUpdateParams.Compaction | null;
    /**
     * Experimental settings to merge by key. Omitted settings keep their current
     * values.
     */
    experimental?: AgentUpdateParams.Experimental;
    /**
     * Additional instructions appended to the agent's default base instructions. Omit
     * to leave unchanged.
     */
    instructions?: string | null;
    /**
     * Replaces all metadata. Omit to leave unchanged, or pass null or {} to clear it.
     * Up to 16 string key-value pairs, with keys up to 64 and values up to 512
     * characters.
     */
    metadata?: {
        [key: string]: string;
    } | null;
    /**
     * The model to use for the agent. The requested model name is preserved.
     */
    model?: string;
    /**
     * Configuration for creating and coordinating subagents.
     */
    multi_agent?: MultiAgentConfigParam | null;
    /**
     * A replacement name. Omit to leave unchanged, or pass null to clear it.
     */
    name?: string | null;
    /**
     * Configuration for model reasoning. Omit to keep the current settings; pass
     * `null` to reset to the model's default effort.
     */
    reasoning?: AgentReasoningParam | null;
    /**
     * The service tier used for model requests.
     *
     * - `auto` - Selects the service tier automatically.
     * - `default` - Uses the default service tier.
     * - `flex` - Uses the flex service tier.
     * - `priority` - Uses the priority service tier.
     * - `fast` - Uses the fast service tier.
     * - `ultrafast` - Uses the ultrafast service tier.
     */
    service_tier?: 'auto' | 'default' | 'flex' | 'priority' | 'fast' | 'ultrafast' | null;
    /**
     * Configuration for text generated by the agent.
     */
    text?: AgentTextParam | null;
    /**
     * Replaces the tool list. Omit to leave it unchanged, or pass null to clear it.
     * The replacement must fit within 3 MiB (3,145,728 bytes) of compact UTF-8 JSON.
     */
    tools?: Array<PersistedAgentToolParam> | null;
}
export declare namespace AgentUpdateParams {
    /**
     * Context compaction settings. Omit to keep the current settings. A supplied
     * object replaces the settings; null or an empty object uses blocking compaction.
     */
    interface Compaction {
        /**
         * Whether to compact context in the background. Omission or null defaults to
         * false. Set to true to enable background compaction. Background compaction may
         * increase token usage.
         */
        async?: boolean | null;
    }
    /**
     * Experimental settings to merge by key. Omitted settings keep their current
     * values.
     */
    interface Experimental {
        /**
         * Whether to give the model periodic current-time reminders. Omit to keep the
         * current setting.
         */
        time_awareness?: boolean;
    }
}
export interface AgentListParams extends CursorPageParams {
    /**
     * The order in which resources are returned. Defaults to `desc`.
     *
     * - `asc` - Returns resources in ascending order.
     * - `desc` - Returns resources in descending order.
     */
    order?: 'asc' | 'desc';
}
export declare namespace EnvironmentParam {
    /** An existing hosted environment, with no inline or template configuration. */
    type EnvironmentParamPrewarmed = {
        type: 'openai_hosted';
        environment_id: string;
    } & {
        [Field in Exclude<keyof EnvironmentParamOpenAIHosted, 'type' | 'environment_id'>]?: never;
    };
}
export declare namespace Agents {
    export { type Agent as Agent, type AgentBrowserAuthenticationCancelParam as AgentBrowserAuthenticationCancelParam, type AgentBrowserAuthenticationSubmitParam as AgentBrowserAuthenticationSubmitParam, type AgentBrowserOriginAccessParam as AgentBrowserOriginAccessParam, type AgentCloseSubagentCallItem as AgentCloseSubagentCallItem, type AgentCommandExecutionItem as AgentCommandExecutionItem, type AgentContent as AgentContent, type AgentCreateSubagentCallItem as AgentCreateSubagentCallItem, type AgentDeleted as AgentDeleted, type AgentFunctionCallItem as AgentFunctionCallItem, type AgentFunctionCallOutput as AgentFunctionCallOutput, type AgentFunctionCallOutputParam as AgentFunctionCallOutputParam, type AgentFunctionCallStatus as AgentFunctionCallStatus, type AgentInterruptSubagentCallItem as AgentInterruptSubagentCallItem, type AgentMcpCallItem as AgentMcpCallItem, type AgentOutputCommandExecutionOutputDeltaEvent as AgentOutputCommandExecutionOutputDeltaEvent, type AgentOutputItem as AgentOutputItem, type AgentOutputItemStatus as AgentOutputItemStatus, type AgentReasoning as AgentReasoning, type AgentReasoningItem as AgentReasoningItem, type AgentReasoningParam as AgentReasoningParam, type AgentResumeSubagentCallItem as AgentResumeSubagentCallItem, type AgentSendSubagentInputCallItem as AgentSendSubagentInputCallItem, type AgentSession as AgentSession, type AgentSessionAssistantMessage as AgentSessionAssistantMessage, type AgentSessionBudgetReachedEvent as AgentSessionBudgetReachedEvent, type AgentSessionCreatedEvent as AgentSessionCreatedEvent, type AgentSessionDeleted as AgentSessionDeleted, type AgentSessionEnvironmentConnectedEvent as AgentSessionEnvironmentConnectedEvent, type AgentSessionEnvironmentDisconnectedEvent as AgentSessionEnvironmentDisconnectedEvent, type AgentSessionEnvironmentExpiredEvent as AgentSessionEnvironmentExpiredEvent, type AgentSessionEnvironmentFailedEvent as AgentSessionEnvironmentFailedEvent, type AgentSessionEnvironmentPendingEvent as AgentSessionEnvironmentPendingEvent, type AgentSessionEnvironmentReadyEvent as AgentSessionEnvironmentReadyEvent, type AgentSessionEnvironmentResetEvent as AgentSessionEnvironmentResetEvent, type AgentSessionEnvironmentState as AgentSessionEnvironmentState, type AgentSessionEnvironmentSuspendedEvent as AgentSessionEnvironmentSuspendedEvent, type AgentSessionErrorEvent as AgentSessionErrorEvent, type AgentSessionEvent as AgentSessionEvent, type AgentSessionFailedEvent as AgentSessionFailedEvent, type AgentSessionIdleEvent as AgentSessionIdleEvent, type AgentSessionInProgressEvent as AgentSessionInProgressEvent, type AgentSessionInputMessageParam as AgentSessionInputMessageParam, type AgentSessionInputParam as AgentSessionInputParam, type AgentSessionItem as AgentSessionItem, type AgentSessionMessage as AgentSessionMessage, type AgentSessionMessageContent as AgentSessionMessageContent, type AgentSessionRequiresActionEvent as AgentSessionRequiresActionEvent, type AgentSessionSubagentActiveEvent as AgentSessionSubagentActiveEvent, type AgentSessionSubagentClosedEvent as AgentSessionSubagentClosedEvent, type AgentSessionSubagentCreatedEvent as AgentSessionSubagentCreatedEvent, type AgentSessionTurnCancelledEvent as AgentSessionTurnCancelledEvent, type AgentSessionTurnCompletedEvent as AgentSessionTurnCompletedEvent, type AgentSessionTurnContentPartAddedEvent as AgentSessionTurnContentPartAddedEvent, type AgentSessionTurnContentPartDoneEvent as AgentSessionTurnContentPartDoneEvent, type AgentSessionTurnCreatedEvent as AgentSessionTurnCreatedEvent, type AgentSessionTurnFailedEvent as AgentSessionTurnFailedEvent, type AgentSessionTurnInProgressEvent as AgentSessionTurnInProgressEvent, type AgentSessionTurnItemAddedEvent as AgentSessionTurnItemAddedEvent, type AgentSessionTurnItemDoneEvent as AgentSessionTurnItemDoneEvent, type AgentSessionTurnOutputTextDeltaEvent as AgentSessionTurnOutputTextDeltaEvent, type AgentSessionTurnOutputTextDoneEvent as AgentSessionTurnOutputTextDoneEvent, type AgentSessionTurnReasoningSummaryPartAddedEvent as AgentSessionTurnReasoningSummaryPartAddedEvent, type AgentSessionTurnReasoningSummaryPartDoneEvent as AgentSessionTurnReasoningSummaryPartDoneEvent, type AgentSessionTurnReasoningSummaryTextDeltaEvent as AgentSessionTurnReasoningSummaryTextDeltaEvent, type AgentSessionTurnReasoningSummaryTextDoneEvent as AgentSessionTurnReasoningSummaryTextDoneEvent, type AgentText as AgentText, type AgentTextParam as AgentTextParam, type AgentTool as AgentTool, type AgentToolParam as AgentToolParam, type AgentWaitForSubagentsCallItem as AgentWaitForSubagentsCallItem, type AgentWebSearchCallItem as AgentWebSearchCallItem, type Environment as Environment, type EnvironmentParam as EnvironmentParam, type HostedEnvironmentFile as HostedEnvironmentFile, type HostedEnvironmentFileID as HostedEnvironmentFileID, type HostedEnvironmentFileParam as HostedEnvironmentFileParam, type HostedPlugin as HostedPlugin, type HostedPluginParam as HostedPluginParam, type HostedSkill as HostedSkill, type HostedSkillParam as HostedSkillParam, type HostedSkillReference as HostedSkillReference, type InlineCapabilitySourceParam as InlineCapabilitySourceParam, type InputContent as InputContent, type InputContentParam as InputContentParam, type McpTransport as McpTransport, type McpTransportParam as McpTransportParam, type MultiAgentConfig as MultiAgentConfig, type MultiAgentConfigParam as MultiAgentConfigParam, type OutputText as OutputText, type PersistedAgentTool as PersistedAgentTool, type PersistedAgentToolParam as PersistedAgentToolParam, type PersistedMcpTransport as PersistedMcpTransport, type PersistedMcpTransportParam as PersistedMcpTransportParam, type SessionError as SessionError, type SessionTurnError as SessionTurnError, type SetupCommandParam as SetupCommandParam, type Subagent as Subagent, type SummaryText as SummaryText, type TextFormat as TextFormat, type TextFormatParam as TextFormatParam, type TokenUsage as TokenUsage, type WebSearchAction as WebSearchAction, type AgentsPage as AgentsPage, type AgentCreateParams as AgentCreateParams, type AgentUpdateParams as AgentUpdateParams, type AgentListParams as AgentListParams, };
    export { Automations as Automations, type Automation as Automation, type AutomationAgentConfig as AutomationAgentConfig, type AutomationCreatedBy as AutomationCreatedBy, type AutomationDeleted as AutomationDeleted, type AutomationEnvironment as AutomationEnvironment, type AutomationTarget as AutomationTarget, type AutomationTargetParam as AutomationTargetParam, type OneTimeAutomation as OneTimeAutomation, type PeriodicAutomation as PeriodicAutomation, type CreateAutomationParamsPeriodic as CreateAutomationParamsPeriodic, type CreateAutomationParamsOnce as CreateAutomationParamsOnce, type AutomationsPage as AutomationsPage, type AutomationCreateParams as AutomationCreateParams, type AutomationUpdateParams as AutomationUpdateParams, type AutomationListParams as AutomationListParams, };
    export { Environments as Environments, type EnvironmentInfo as EnvironmentInfo, type EnvironmentInfosPage as EnvironmentInfosPage, type EnvironmentCreateParams as EnvironmentCreateParams, type EnvironmentListParams as EnvironmentListParams, };
    export { Vaults as Vaults, type Vault as Vault, type VaultDeleted as VaultDeleted, type VaultStatus as VaultStatus, type VaultStatusFilter as VaultStatusFilter, type VaultsPage as VaultsPage, type VaultCreateParams as VaultCreateParams, type VaultUpdateParams as VaultUpdateParams, type VaultListParams as VaultListParams, };
    export { Sessions as Sessions, type SessionCreateParams as SessionCreateParams, type SessionCreateParamsNonStreaming as SessionCreateParamsNonStreaming, type SessionCreateParamsStreaming as SessionCreateParamsStreaming, type SessionUpdateParams as SessionUpdateParams, type SessionListParams as SessionListParams, };
}
//# sourceMappingURL=agents.d.mts.map